var t,pac;
var Arrex,Arrey;
Arrex=8;
Arrey=10;
var Arre= [
	[1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1],
	[1,0,0,1,0,0,0,1,0,1,0,0,0,1,0,0,1],
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
	[1,0,0,1,0,1,0,0,0,0,0,1,0,1,0,0,1],
	[1,1,1,1,0,1,1,1,0,1,1,1,0,1,1,1,1],
	[0,0,0,1,0,0,0,1,0,1,0,0,0,1,0,0,0],
	[0,0,0,1,0,1,1,1,1,1,1,1,0,1,0,0,0],
	[0,0,0,1,0,1,0,0,1,0,0,1,0,1,0,0,0],
	[1,1,1,1,1,1,0,1,1,1,0,1,1,1,1,1,1],
	[0,0,0,1,0,1,0,0,0,0,0,1,0,1,0,0,0],
	[0,0,0,1,0,1,1,1,1,1,1,1,0,1,0,0,0],
	[0,0,0,1,0,1,0,0,0,0,0,1,0,1,0,0,0],
	[1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1],
	[1,0,0,1,0,0,0,1,0,1,0,0,0,1,0,0,1],
	[1,1,0,1,1,1,1,1,1,1,1,1,1,1,0,1,1],
	[0,1,0,1,0,1,0,0,0,0,0,1,0,1,0,1,0],
	[1,1,1,1,0,1,1,1,0,1,1,1,0,1,1,1,1],
	[1,0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,1],
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]];
var ArrePepa= [
	[1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1],
	[1,0,0,1,0,0,0,1,0,1,0,0,0,1,0,0,1],
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
	[1,0,0,1,0,1,0,0,0,0,0,1,0,1,0,0,1],
	[1,1,1,1,0,1,1,1,0,1,1,1,0,1,1,1,1],
	[0,0,0,1,0,0,0,1,0,1,0,0,0,1,0,0,0],
	[0,0,0,1,0,1,1,1,1,1,1,1,0,1,0,0,0],
	[0,0,0,1,0,1,0,0,0,0,0,1,0,1,0,0,0],
	[1,1,1,1,1,1,0,0,0,0,0,1,1,1,1,1,1],
	[0,0,0,1,0,1,0,0,0,0,0,1,0,1,0,0,0],
	[0,0,0,1,0,1,1,1,0,1,1,1,0,1,0,0,0],
	[0,0,0,1,0,1,0,0,0,0,0,1,0,1,0,0,0],
	[1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1],
	[1,0,0,1,0,0,0,1,0,1,0,0,0,1,0,0,1],
	[1,1,0,1,1,1,1,1,1,1,1,1,1,1,0,1,1],
	[0,1,0,1,0,1,0,0,0,0,0,1,0,1,0,1,0],
	[1,1,1,1,0,1,1,1,0,1,1,1,0,1,1,1,1],
	[1,0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,1],
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]];
var fondo={
	URL:"Tablero.jpg",
	Carga:false
}
var Pepa={
	URL:"Pepa.png",
	Carga:false
}
var PacMan={
	x:345,
	y:425,
	URLder:"PacManDer.png",
	CargaDer:false,
	URLizq:"PacManIzq.png",
	CargaIzq:false,
	URLarr:"PacManArr.png",
	CargaArr:false,
	URLaba:"PacManAba.png",
	CargaAba:false
}
function inicio(){
	t=document.getElementById("Tablero").getContext("2d");
	fondo.imagen=new Image();
	fondo.imagen.src=fondo.URL;
	fondo.imagen.onload=ValidarCargaFondo;

	PacMan.imagenIzq=new Image();
	PacMan.imagenIzq.src=PacMan.URLizq;
	PacMan.imagenIzq.onload=ValidarCargaPacManIzq;

	PacMan.imagenDer=new Image();
	PacMan.imagenDer.src=PacMan.URLder;
	PacMan.imagenDer.onload=ValidarCargaPacManDer;

	PacMan.imagenAba=new Image();
	PacMan.imagenAba.src=PacMan.URLaba;
	PacMan.imagenAba.onload=ValidarCargaPacManAba;

	PacMan.imagenArr=new Image();
	PacMan.imagenArr.src=PacMan.URLarr;
	PacMan.imagenArr.onload=ValidarCargaPacManArr;

	Pepa.imagenPepa=new Image();
	Pepa.imagenPepa.src=Pepa.URL;
	Pepa.imagenPepa.onload=ValidarCargaPepa;

	document.addEventListener("keydown",teclado);
}
function ValidarCargaFondo(){
	fondo.Carga=true; 
	pac=PacMan.imagenDer;
	dibujar();
}
function ValidarCargaPacManIzq(){
	PacMan.CargaIzq=true;
	dibujar();
}
function ValidarCargaPacManDer(){
	PacMan.CargaDer=true;
	dibujar();
}
function ValidarCargaPacManArr(){
	PacMan.CargaArr=true;
	dibujar();
}
function ValidarCargaPacManAba(){
	PacMan.CargaAba=true;
	dibujar();
}
function ValidarCargaPepa(){
	Pepa.Carga=true;
	dibujar();
}
function dibujar(){
	if (fondo.Carga) {
		t.drawImage(fondo.imagen,0,0);	
	}
	if(Pepa.Carga){
		for (var i = 0; i <= 18; i++) {
			for (var j = 0; j <= 16; j++) {
				if ((ArrePepa[i][j])==1) {
					t.drawImage(Pepa.imagenPepa,(j*40)+25,(i*40)+25);
				}
			}
		}
	}
	if (PacMan.CargaDer) {
		t.drawImage(pac,PacMan.x,PacMan.y);	
	}
}
function teclado(datos){
	console.log(datos);
	if (datos.key=="ArrowUp") {
		pac=PacMan.imagenArr;
		if ((Arre[Arrey-1][Arrex])==1) {
			PacMan.y-=40;
			Arrey--;
		}
		dibujar();
	}
	if (datos.key=="ArrowDown") {
		pac=PacMan.imagenAba;
		if ((Arre[Arrey+1][Arrex])==1) {
			PacMan.y+=40;
			Arrey++;
		}
		dibujar();
	}
	if (datos.key=="ArrowLeft") {
		pac=PacMan.imagenIzq;
		if ((Arre[Arrey][Arrex-1])==1) {
			PacMan.x-=40;
			Arrex--;
		}
		dibujar();
	}
	if (datos.key=="ArrowRight") {
		pac=PacMan.imagenDer;			
		if ((Arre[Arrey][Arrex+1])==1) {
			PacMan.x+=40;
			Arrex++;
		}
		dibujar();
	}	
	if(ArrePepa[Arrey][Arrex]==Arre[Arrey][Arrex]){//Borar pepa
		ArrePepa[Arrey][Arrex]=0;
	}	
}