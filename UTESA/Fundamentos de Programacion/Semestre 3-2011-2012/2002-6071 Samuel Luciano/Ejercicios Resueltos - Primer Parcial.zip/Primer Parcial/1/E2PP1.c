int main(){
    int n1, n2, n3;
    printf("Introduzca un numero: ");
    scanf("%d", &n1);
    printf("Introduzca un numero: ");
    scanf("%d", &n2);
    printf("Introduzca un numero: ");
    scanf("%d", &n3);
    if((n1 > n2 && n2 > n3) || (n1 < n2 && n2 < n3){
        printf("Los numeros en orden.");
    } else {
        printf("Los numeros no estan en orden.");
    }
}
