using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Text;
using System.IO;
using System.Security;
using System.Security.Permissions;

namespace CASLab
{
	/// <summary>
	/// Summary description for MainForm.
	/// </summary>
	public class MainForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button DemandAssertButton;
		private System.Windows.Forms.Button EnvVarButton;
		private System.Windows.Forms.Button FileButton;
		private System.Windows.Forms.Label ResultsLabel;
		private System.Windows.Forms.Button ExitButton;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public MainForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.DemandAssertButton = new System.Windows.Forms.Button();
			this.EnvVarButton = new System.Windows.Forms.Button();
			this.FileButton = new System.Windows.Forms.Button();
			this.ResultsLabel = new System.Windows.Forms.Label();
			this.ExitButton = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// DemandAssertButton
			// 
			this.DemandAssertButton.Location = new System.Drawing.Point(16, 16);
			this.DemandAssertButton.Name = "DemandAssertButton";
			this.DemandAssertButton.Size = new System.Drawing.Size(152, 24);
			this.DemandAssertButton.TabIndex = 0;
			this.DemandAssertButton.Text = "Demand and Assert";
			this.DemandAssertButton.Click += new System.EventHandler(this.DemandAssertButton_Click);
			// 
			// EnvVarButton
			// 
			this.EnvVarButton.Location = new System.Drawing.Point(16, 48);
			this.EnvVarButton.Name = "EnvVarButton";
			this.EnvVarButton.Size = new System.Drawing.Size(152, 23);
			this.EnvVarButton.TabIndex = 1;
			this.EnvVarButton.Text = "Read Environment Variable";
			this.EnvVarButton.Click += new System.EventHandler(this.EnvVarButton_Click);
			// 
			// FileButton
			// 
			this.FileButton.Location = new System.Drawing.Point(16, 80);
			this.FileButton.Name = "FileButton";
			this.FileButton.Size = new System.Drawing.Size(152, 23);
			this.FileButton.TabIndex = 2;
			this.FileButton.Text = "Open File";
			this.FileButton.Click += new System.EventHandler(this.FileButton_Click);
			// 
			// ResultsLabel
			// 
			this.ResultsLabel.Location = new System.Drawing.Point(16, 112);
			this.ResultsLabel.Name = "ResultsLabel";
			this.ResultsLabel.Size = new System.Drawing.Size(152, 120);
			this.ResultsLabel.TabIndex = 3;
			this.ResultsLabel.Text = "Results:";
			// 
			// ExitButton
			// 
			this.ExitButton.Location = new System.Drawing.Point(96, 240);
			this.ExitButton.Name = "ExitButton";
			this.ExitButton.TabIndex = 4;
			this.ExitButton.Text = "Exit";
			this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
			// 
			// MainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(184, 278);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.ExitButton,
																		  this.ResultsLabel,
																		  this.FileButton,
																		  this.EnvVarButton,
																		  this.DemandAssertButton});
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "MainForm";
			this.Text = "CAS Lab";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new MainForm());
		}

		private void ExitButton_Click(object sender, System.EventArgs e)
		{
			this.Close();
			Application.Exit();
		}

		private void DemandAssertButton_Click(object sender, System.EventArgs e)
		{
			ResultsLabel.Text = "Results:\n";

            // TODO: crear el EnvironmentPermission
            // para leer la variable de ambiente USERNAME.


			try
			{
                // TODO: realizar el demand del EnvironmentPermission.


				ResultsLabel.Text += "Demand for enivronment permission succeeded\n";

                // TODO: crear el SecurityPermission para invocar
                // codigo no manejado.


				try
				{
                    // TODO: realizar el assert del SecurityPermission


					ResultsLabel.Text += "Assert of unmanaged code permission succeeded\n";

					try
					{
                        // la llamada al codigo no manejado va aqu�, la siguiente
                        // es una llamada simulada.
                        unmanagedCall();
						ResultsLabel.Text += "Call to unmanaged code succeeded";
					}
					catch (SecurityException se)
					{
                        // si se ejecuta una SecurityException, nuestro codigo
                        // no posee los permisos necesarior para
                        // llamar al codigo no manejado.
                        ResultsLabel.Text += "Call to unmanaged code failed\nError message: " + se.Message;
					}
					catch
					{
						ResultsLabel.Text += "Call to unmanaged code failed due to an unknown error";
					}
					finally
					{
                        // TODO: quite el assert desde el stack inmediatamente
                        // despues de llamar al codigo no manejado.

					}
				}
				catch (SecurityException se)
				{
                    // si se ejecuta SecurityException aqui, nuestro
                    // codigo no tiene los permisos necesarios para realizar
                    // el assert satisfactoriamente.
                    ResultsLabel.Text += "Assert failed\nError message: " + se.Message;
				}
				catch
				{
					ResultsLabel.Text += "Assert failed due to an unknown error";
				}
			}
			catch (SecurityException se)
			{
                // si se ejecuta SecurityException aqui, nuestro
                // codigo no tiene los permisos necesarios para realizar
                // el demand satisfactoriamente.
                ResultsLabel.Text += "Demand failed\nError message: " + se.Message;
			}
			catch
			{
				ResultsLabel.Text += "Demand failed due to an unknown error";
			}
		}

		private void EnvVarButton_Click(object sender, System.EventArgs e)
		{
			StringBuilder outputText = new StringBuilder();
			outputText.Append("Results: ");

			try
			{
				Environment.GetEnvironmentVariable("USERNAME");
				outputText.Append("Successfully read USERNAME enviroment variable.");
			}
			catch (SecurityException se)
			{
				outputText.Append("Failed to read USERNAME environment variable due to security exception.\nException message: ");
				outputText.Append(se.Message);
			}
			catch
			{
				outputText.Append("Failed to read USERNAME environment variable due to other exception.");
			}

			ResultsLabel.Text = outputText.ToString();
		}

		private void FileButton_Click(object sender, System.EventArgs e)
		{
			FileStream stream = null;
			StringBuilder outputText = new StringBuilder();
			outputText.Append("Results: ");

			try
			{
				stream = new FileStream("C:\\test.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
				outputText.Append("Successfully opened C:\\test.txt file.");
			}
			catch (SecurityException se)
			{
				outputText.Append("Failed to to open C:\\test.txt file due to security exception.\nException message: ");
				outputText.Append(se.Message);
			}
			catch
			{
				outputText.Append("Failed to open C:\\test.txt file due to other exception.");
			}
			finally
			{
				if (stream != null)
					stream.Close();
			}

			ResultsLabel.Text = outputText.ToString();		
		}

		private void unmanagedCall()
		{
			SecurityPermission secPerm = new SecurityPermission(SecurityPermissionFlag.UnmanagedCode);
			secPerm.Demand();
		}
	}
}
