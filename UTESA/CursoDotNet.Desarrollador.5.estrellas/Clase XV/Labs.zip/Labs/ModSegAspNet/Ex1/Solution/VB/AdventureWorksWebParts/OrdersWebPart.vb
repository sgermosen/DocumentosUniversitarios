Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Data
Imports System.Data.SqlClient

Public Class OrdersWebPart
    Inherits WebPart

    Private _empId As Integer = 1
    Private _data As DataTable = Nothing

    <ConnectionConsumer("EmployeeIDConsumer", _
    "EmployeeIDConsumer")> _
    Public Sub GetEmployeeInfo( _
        ByVal empInfo As IEmployeeInfo)
        If Not empInfo Is Nothing Then
            _empId = empInfo.EmployeeID
            FindEmployeeInfo()
        Else
            Throw New NotSupportedException( _
                "No connection data found.")
        End If
    End Sub

    Private Sub FindEmployeeInfo()
        If _empId < 1 Then
            Return
        End If

        Dim adapter As SqlDataAdapter
        adapter = New SqlDataAdapter( _
        "SELECT orderid, customerid, employeeid, " + _
  "orderdate FROM orders WHERE employeeid=" + _
  _empId.ToString(), _
        "SERVER=(local);DATABASE=northwind;UID=sa;PASSWORD=P@ssw0rd")
        _data = New DataTable()

        adapter.Fill(_data)
    End Sub

    Private Sub BuildUI(ByVal writer As HtmlTextWriter)
        Dim _grid As DataGrid = New DataGrid()
        _grid.AutoGenerateColumns = True
        _grid.Font.Name = "verdana"
        _grid.Font.Size = FontUnit.Point(8)
        _grid.HeaderStyle.Font.Bold = True
        _grid.DataSource = _data
        _grid.DataBind()
        _grid.RenderControl(writer)
    End Sub

    Protected Overrides Sub RenderContents( _
        ByVal writer As HtmlTextWriter)
        If _empId < 1 Then

            writer.Write("<span style='color:gray'>" + _
            "No employee is currently selected.</span>")
            Return
        End If

        ' Grab info and generate the UI
        FindEmployeeInfo()
        BuildUI(writer)
    End Sub

End Class
