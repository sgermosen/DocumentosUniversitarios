#region Using directives

using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Data;
using System.Data.SqlClient;

#endregion

namespace AdventureWorksWebParts
{
    public class OrdersWebPart : WebPart
    {
        private int _empID = 1;
        private DataTable _data = null;

        public OrdersWebPart()
        {

        }

        [ConnectionConsumer("EmployeeIDConsumer", "EmployeeIDConsumer")]
        public void GetEmployeeInfo(IEmployeeInfo empInfo)
        {
            if (empInfo != null)
            {
                _empID = empInfo.EmployeeID;
                FindEmployeeInfo();
            }
            else
            {
                throw new NotSupportedException("No connection data found.");
            }
        }

        private void FindEmployeeInfo()
        {
            if (_empID < 1)
                return;

            SqlDataAdapter adapter;
            adapter = new SqlDataAdapter(
                "SELECT orderid, customerid, employeeid, " +
                "orderdate FROM orders WHERE employeeid=" +
                _empID.ToString(),
                "SERVER=(local);DATABASE=northwind;UID=sa;PASSWORD=P@ssw0rd");
            _data = new DataTable();

            adapter.Fill(_data);
        }

        private void BuildUI(HtmlTextWriter writer)
        {
            DataGrid _grid = new DataGrid();
            _grid.AutoGenerateColumns = true;
            _grid.Font.Name = "verdana";
            _grid.Font.Size = FontUnit.Point(8);
            _grid.HeaderStyle.Font.Bold = true;
            _grid.DataSource = _data;
            _grid.DataBind();
            _grid.RenderControl(writer);
        }

        protected override void RenderContents(HtmlTextWriter writer)
        {
            if (_empID < 1)
            {
                writer.Write("<span style='color:gray'>" +
                    "No employee is currently selected.</span>");
                return;
            }

            // Grab info and generate the UI
            FindEmployeeInfo();
            BuildUI(writer);
        }

    }
}