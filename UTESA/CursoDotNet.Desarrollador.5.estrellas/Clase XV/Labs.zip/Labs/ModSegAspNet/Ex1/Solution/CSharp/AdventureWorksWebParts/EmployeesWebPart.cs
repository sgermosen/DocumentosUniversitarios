#region Using directives

using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Data;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Xml;
#endregion

public interface IEmployeeInfo
{
    int EmployeeID { get; set; }
}

namespace AdventureWorksWebParts
{
    public class EmployeesWebPart : WebPart, IEmployeeInfo
    {
        private int _empID = 1;
        private DataTable _data = null;
        private TextBox txt;
        private Button btn;

        public EmployeesWebPart()
        {

        }

        [
        ConnectionProvider("EmployeeIDProvider",
            "EmployeeIDProvider")
        ]
        public IEmployeeInfo ProvideEmployeeInfo()
        {
            return this;
        }

        [
        Personalizable(true),
        WebBrowsable(true)
        ]
        public int EmployeeID
        {
            get { return _empID; }
            set { _empID = value; }
        }

        protected override void OnLoad(EventArgs e)
        {
            txt = new TextBox();
            txt.BorderStyle = BorderStyle.Solid;
            txt.BorderWidth = Unit.Pixel(1);
            txt.Width = Unit.Pixel(30);
            txt.Height = Unit.Pixel(20);
            txt.Text = EmployeeID.ToString();
            Controls.Add(txt);

            btn = new Button();
            btn.BorderStyle = BorderStyle.Solid;
            btn.BorderWidth = Unit.Pixel(1);
            btn.Height = Unit.Pixel(20);
            btn.Font.Size = FontUnit.Point(8);
            btn.Text = "Find";
            btn.Click += new EventHandler(OnFindEmployee);
            Controls.Add(btn);
        }

        private void OnFindEmployee(Object sender, EventArgs e)
        {
            if (txt.Text != String.Empty)
            {
                _empID = Convert.ToInt32(txt.Text);
            }
        }

        private void FindEmployeeInfo()
        {
            if (_empID < 1)
                return;
            SqlDataAdapter adapter;
            adapter = new SqlDataAdapter(
                "SELECT * FROM employees WHERE employeeid="
                    + _empID.ToString(),
                "SERVER=(local);DATABASE=northwind;UID=sa;PASSWORD=P@ssw0rd");
            _data = new DataTable();

            adapter.Fill(_data);
        }

        private void RenderEmployeeInfo(HtmlTextWriter writer)
        {
            Table _table = new Table();

            // ID field
            TableRow id = new TableRow();
            TableCell id_cell1 = new TableCell();

            id_cell1.VerticalAlign = VerticalAlign.Top;
            id_cell1.Text = "<b>ID<b>";
            id.Cells.Add(id_cell1);

            TableCell id_cell2 = new TableCell();

            id_cell2.Text = _data.Rows[0]["employeeid"].ToString();
            id.Cells.Add(id_cell2);
            _table.Rows.Add(id);

            // Name field
            TableRow name = new TableRow();
            TableCell name_cell1 = new TableCell();

            name_cell1.VerticalAlign = VerticalAlign.Top;
            name_cell1.Text = "<b>Name<b>";
            name.Cells.Add(name_cell1);

            TableCell name_cell2 = new TableCell();

            name_cell2.Text = String.Format("{0}, {1}", _data.Rows[0]["lastname"].ToString(), _data.Rows[0]["firstname"].ToString());
            name.Cells.Add(name_cell2);
            _table.Rows.Add(name);

            // Title field
            TableRow title = new TableRow();
            TableCell title_cell1 = new TableCell();

            title_cell1.VerticalAlign = VerticalAlign.Top;
            title_cell1.Text = "<b>Position<b>";
            title.Cells.Add(title_cell1);

            TableCell title_cell2 = new TableCell();

            title_cell2.Text = _data.Rows[0]["title"].ToString();
            title.Cells.Add(title_cell2);
            _table.Rows.Add(title);

            // Notes field
            TableRow notes = new TableRow();
            TableCell notes_cell1 = new TableCell();

            notes_cell1.VerticalAlign = VerticalAlign.Top;
            notes_cell1.Text = "<b>Notes<b>";
            notes.Cells.Add(notes_cell1);

            TableCell notes_cell2 = new TableCell();

            notes_cell2.Text = _data.Rows[0]["notes"].ToString();
            notes.Cells.Add(notes_cell2);
            _table.Rows.Add(notes);
            _table.RenderControl(writer);

        }

        private void RenderQueryStructure(HtmlTextWriter writer)
        {
            writer.Write("Enter employee ID: ");
            txt.RenderControl(writer);
            btn.RenderControl(writer);
            writer.Write("<hr size=1>");
        }

        protected override void RenderContents(HtmlTextWriter writer)
        {
            if (_empID < 1)
            {
                writer.Write("<span style='color:gray'>" +
                    "No employee is currently selected.</span>");
                return;
            }

            RenderQueryStructure(writer);

            // Grab info and generate the UI
            FindEmployeeInfo();

            if (_data.Rows.Count <= 0)
            {
                writer.Write("<span style='color:gray'>" +
                    "No data is currently available.</span>");
                return;
            }

            RenderEmployeeInfo(writer);
        }
    }
}