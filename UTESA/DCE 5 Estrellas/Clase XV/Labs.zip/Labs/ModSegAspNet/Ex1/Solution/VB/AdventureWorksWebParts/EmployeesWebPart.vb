Imports System
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.ComponentModel
Imports System.Xml
Imports System.Data
Imports System.Data.SqlClient


Public Interface IEmployeeInfo
    Property EmployeeID() As Integer
End Interface

Public Class EmployeesWebPart
    Inherits WebPart
    Implements IEmployeeInfo

    Private _empId As Integer = 1
    Private _data As DataTable = Nothing
    Private txt As TextBox
    Private btn As Button

    <Personalizable(True), _
    WebBrowsable(True)> _
    Public Property EmployeeID() As Integer _
        Implements IEmployeeInfo.EmployeeID
        Get
            Return _empId
        End Get
        Set(ByVal value As Integer)
            _empId = value
        End Set
    End Property

    <ConnectionProvider("EmployeeIDProvider", _
        "EmployeeIDProvider")> _
    Public Function ProvideEmployeeInfo() _
        As IEmployeeInfo
        Return Me
    End Function

    Protected Overrides Sub OnLoad(ByVal e As EventArgs)
        txt = New TextBox()
        txt.BorderStyle = BorderStyle.Solid
        txt.BorderWidth = Unit.Pixel(1)
        txt.Width = Unit.Pixel(30)
        txt.Height = Unit.Pixel(20)
        txt.Text = EmployeeID.ToString()
        Controls.Add(txt)

        btn = New Button()
        btn.BorderStyle = BorderStyle.Solid
        btn.BorderWidth = Unit.Pixel(1)
        btn.Height = Unit.Pixel(20)
        btn.Font.Size = FontUnit.Point(8)
        btn.Text = "Find"
        AddHandler btn.Click, AddressOf OnFindEmployee
        Controls.Add(btn)
    End Sub

    Private Sub OnFindEmployee(ByVal Sender As Object, _
        ByVal e As EventArgs)
        If txt.Text <> String.Empty Then
            _empId = Convert.ToInt32(txt.Text)
        End If
    End Sub

    Private Sub FindEmployeeInfo()
        If _empId < 1 Then Return
        Dim adapter As SqlDataAdapter
        adapter = New SqlDataAdapter( _
            "SELECT * FROM employees WHERE employeeid=" _
            + _empId.ToString(), _
            "SERVER=(local);DATABASE=northwind;UID=sa;PASSWORD=P@ssw0rd")

        _data = New DataTable()

        adapter.Fill(_data)
    End Sub

    Private Sub RenderEmployeeInfo(ByVal writer As HtmlTextWriter)
        Dim _table As Table = New Table()

        ' ID field
        Dim id As TableRow = New TableRow()
        Dim id_cell1 As TableCell = New TableCell()

        id_cell1.VerticalAlign = VerticalAlign.Top
        id_cell1.Text = "<b>ID<b>"
        id.Cells.Add(id_cell1)

        Dim id_cell2 As TableCell = New TableCell()

        id_cell2.Text = _
            _data.Rows(0)("employeeid").ToString()
        id.Cells.Add(id_cell2)
        _table.Rows.Add(id)

        ' Name field
        Dim name As TableRow = New TableRow()
        Dim name_cell1 As TableCell = New TableCell()

        name_cell1.VerticalAlign = VerticalAlign.Top
        name_cell1.Text = "<b>Name<b>"
        name.Cells.Add(name_cell1)

        Dim name_cell2 As TableCell = New TableCell()

        name_cell2.Text = String.Format("{0}, {1}", _
      _data.Rows(0)("lastname").ToString(), _
      _data.Rows(0)("firstname").ToString())
        name.Cells.Add(name_cell2)
        _table.Rows.Add(name)

        ' Title field
        Dim title As TableRow = New TableRow()
        Dim title_cell1 As TableCell = New TableCell()

        title_cell1.VerticalAlign = VerticalAlign.Top
        title_cell1.Text = "<b>Position<b>"
        title.Cells.Add(title_cell1)

        Dim title_cell2 As TableCell = New TableCell()

        title_cell2.Text = _data.Rows(0)("title").ToString()
        title.Cells.Add(title_cell2)
        _table.Rows.Add(title)

        ' Notes field
        Dim notes As TableRow = New TableRow()
        Dim notes_cell1 As TableCell = New TableCell()

        notes_cell1.VerticalAlign = VerticalAlign.Top
        notes_cell1.Text = "<b>Notes<b>"
        notes.Cells.Add(notes_cell1)

        Dim notes_cell2 As TableCell = New TableCell()

        notes_cell2.Text = _data.Rows(0)("notes").ToString()
        notes.Cells.Add(notes_cell2)
        _table.Rows.Add(notes)
        _table.RenderControl(writer)

    End Sub

    Private Sub RenderQueryStructure( _
        ByVal writer As HtmlTextWriter)
        writer.Write("Enter employee ID: ")
        txt.RenderControl(writer)
        btn.RenderControl(writer)
        writer.Write("<hr size=1>")
    End Sub

    Protected Overrides Sub RenderContents( _
    ByVal writer As HtmlTextWriter)
        If _empId < 1 Then
            writer.Write("<span style='color:gray'>" + _
            "No employee is currently selected.</span>")
            Return
        End If

        ' Grab info and generate the UI
        FindEmployeeInfo()
        RenderQueryStructure(writer)

        If _data.Rows.Count <= 0 Then
            writer.Write("<span style='color:gray'>" + _
               "No data is currently available.</span>")
            Return
        End If
        RenderEmployeeInfo(writer)
    End Sub

End Class
