using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls.WebParts;
namespace myControls
{
    public class FeaturedProductPart1 : WebPart
    {
        const string connectionString =
      "Server=localhost;Trusted_Connection=True;Database=Northwind";
        const string selectString = "SELECT * FROM Products";
        public FeaturedProductPart1()
        {
            this.Title = "Featured Product";
        }
        protected override void RenderContents(HtmlTextWriter writer)
        {
            // Load Products into DataTable
            DataTable productTable = new DataTable();
            SqlDataAdapter dad = new SqlDataAdapter(selectString,
              connectionString);
            dad.Fill(productTable);
            // Randomly select a row
            Random rnd = new Random();
            DataRow row =
              productTable.Rows[rnd.Next(productTable.Rows.Count)];
            // Render the row
            writer.Write((string)row["ProductName"]);
            writer.Write(String.Format("- {0:c}", row["UnitPrice"]));
        }
    }
}
