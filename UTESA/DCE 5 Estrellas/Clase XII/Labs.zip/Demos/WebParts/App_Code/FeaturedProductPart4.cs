using System;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls.WebParts;
namespace myControls
{
    public class FeaturedProductPart4 : WebPart
    {
        const string connectionString =
        "Server=localhost;Trusted_Connection=True;Database=Northwind";
        const string selectString = "SELECT * FROM Products " +
        "JOIN Categories ON Products.CategoryID=Categories.CategoryID";
        private string _categoryName = "Beverages";
        private ICategoryInterface _category;
        public FeaturedProductPart4()
        {
            this.Title = "Featured Product";
        }
        [Personalizable, WebBrowsable]
        public string CategoryName
        {
            get { return _categoryName; }
            set { _categoryName = value; }
        }
        [ConnectionConsumer("Category")]
        public void GetInterface(ICategoryInterface myInterface)
        {
            _category = myInterface;
        }

        protected override void OnPreRender(EventArgs e)
        {
            if (_category != null)
            {
                CategoryName = _category.SelectedCategory;
                this.Title = String.Format("Featured Product - {0}",
                  CategoryName);
            }
        }
        protected override void RenderContents(HtmlTextWriter writer)
        {
            // Load Products into DataTable
            DataTable productTable = new DataTable();
            SqlDataAdapter dad = new SqlDataAdapter(selectString,
              connectionString);
            dad.Fill(productTable);
            // Filter the DataTable with a Category
            DataView productView = productTable.DefaultView;
            productView.RowFilter = "CategoryName='" +
              _categoryName + "'";
            if (productView.Count == 0)
                return;
            // Randomly select a row
            Random rnd = new Random();
            DataRowView row = productView[rnd.Next(productView.Count)];
            // Render the row
            writer.Write((string)row["ProductName"]);
            writer.Write(String.Format("- {0:c}", row["UnitPrice"]));
        }
    }
}
