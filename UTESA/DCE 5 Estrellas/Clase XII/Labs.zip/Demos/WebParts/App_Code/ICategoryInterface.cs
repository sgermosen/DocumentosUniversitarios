namespace myControls
{
    public interface ICategoryInterface
    {
        string SelectedCategory { get; }
    }
}
