using System;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
namespace myControls
{

    public class SelectCategoryPart : WebPart, ICategoryInterface
    {
        DropDownList dropCategories;
        public SelectCategoryPart()
        {
            this.Title = "Product Category";
        }
        public string SelectedCategory
        {
            get
            {
                EnsureChildControls();
                return dropCategories.SelectedValue;
            }
        }
        [ConnectionProvider("Category")]
        public ICategoryInterface ProvideInterface()
        {
            return this;
        }
        protected override void CreateChildControls()
        {
            dropCategories = new DropDownList();
            dropCategories.AutoPostBack = true;
            dropCategories.Items.Add("Beverages");
            dropCategories.Items.Add("Seafood");
            Controls.Add(dropCategories);
        }
    }
}
