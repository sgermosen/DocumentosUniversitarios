USE credit
IF EXISTS (SELECT name FROM sysobjects WHERE id = OBJECT_ID('index_cleanup')
		AND OBJECTPROPERTY(OBJECT_ID('index_cleanup'),'IsProcedure')=1)
   DROP PROCEDURE index_cleanup
GO
CREATE PROCEDURE index_cleanup
	@tabname nvarchar(150) -- Table name to drop index and statistics from.
AS
/*
**  This stored procedure DROPS all INDEXES and STATISTICS
**  for a specified table in a database.
**
**  Syntax: EXEC index_cleanup <tablename>
**
**  This stored procedure assumes that no CONSTRAINTS exist. It
**  only checks for existing indexes and statistics and drops them.
*/

DECLARE @idx_name        nvarchar(150) -- Name of index or statistic to drop.
DECLARE @drop_idx_string nvarchar(200) -- Dynamic string that DROPS the index/stats.

SET NOCOUNT ON

--  See if the table exists
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES 
	       WHERE table_type = 'base table' AND table_name = @tabname)
	BEGIN
		RAISERROR('The table: ''%s'' does not exist.',16, 1, @tabname)
		RETURN (1)
	END

SET @tabname = OBJECT_ID(@tabname)
IF EXISTS (SELECT id FROM sysindexes
	   WHERE id=@tabname AND indid BETWEEN 1 AND 254
			     AND status IN (96,10485856,8388704))
BEGIN
   DECLARE idx_cursor CURSOR 
      FOR SELECT name FROM sysindexes
	  WHERE id=@tabname AND indid BETWEEN 1 AND 254
			    AND status IN (96,10485856,8388704)
   OPEN idx_cursor
   FETCH NEXT FROM idx_cursor INTO @idx_name
     WHILE @@FETCH_STATUS = 0
	BEGIN
	   SET @drop_idx_string = ('DROP STATISTICS '+OBJECT_NAME(@tabname)+'.'+@idx_name)
	   EXECUTE(@drop_idx_string)
	   FETCH NEXT FROM idx_cursor INTO @idx_name
	END
   CLOSE idx_cursor
   DEALLOCATE idx_cursor
END
PRINT '     *** Statistics Deleted ***'

IF EXISTS (SELECT id FROM sysindexes
	   WHERE id=@tabname AND indid BETWEEN 1 AND 254
			     AND status NOT IN (96,10485856,8388704))
BEGIN
   DECLARE idx_cursor CURSOR 
      FOR SELECT name FROM sysindexes
	  WHERE id=@tabname AND indid BETWEEN 1 AND 254
			    AND status NOT IN (96,10485856,8388704)
   OPEN idx_cursor
   FETCH NEXT FROM idx_cursor INTO @idx_name
     WHILE @@FETCH_STATUS = 0
	BEGIN
	   SET @drop_idx_string = ('DROP INDEX '+OBJECT_NAME(@tabname)+'.'+@idx_name)
	   EXECUTE(@drop_idx_string)
	   FETCH NEXT FROM idx_cursor INTO @idx_name
	END
   CLOSE idx_cursor
   DEALLOCATE idx_cursor
END
PRINT '     *** Indexes Deleted ***'

GO

