/*
** Lab 5, Alert.sql
** This script combines 2 script files:
1) Create a multi-step job to backup or truncate the transaction log
   in response to an error (Northwind Free Log Space)
2) Create an alert on error 9002 (Northwind 9002 Full Log).
The job and alert were originally created using SQL Server Enterprise 
Manager and then the scripts were generated. The individual scripts were
then combined into one script file.
*/

/* Create multi-step job in response to alert 9002 */
BEGIN TRANSACTION            
  DECLARE @JobID BINARY(16)  
  DECLARE @ReturnCode INT    
  SELECT @ReturnCode = 0     
IF (SELECT COUNT(*) FROM msdb.dbo.syscategories WHERE name = N'[Uncategorized (Local)]') < 1 
  EXECUTE msdb.dbo.sp_add_category @name = N'[Uncategorized (Local)]'

  -- Delete the job with the same name (if it exists)
  SELECT @JobID = job_id     
  FROM   msdb.dbo.sysjobs    
  WHERE (name = N'Northwind Free Log Space')       
  IF (@JobID IS NOT NULL)    
  BEGIN  
  -- Check if the job is a multi-server job  
  IF (EXISTS (SELECT  * 
              FROM    msdb.dbo.sysjobservers 
              WHERE   (job_id = @JobID) AND (server_id <> 0))) 
  BEGIN 
    -- There is, so abort the script 
    RAISERROR (N'Unable to import job ''Northwind Free Log Space'' since there is already a multi-server job with this name.', 16, 1) 
    GOTO QuitWithRollback  
  END 
  ELSE 
    -- Delete the [local] job 
    EXECUTE msdb.dbo.sp_delete_job @job_name = N'Northwind Free Log Space' 
    SELECT @JobID = NULL
  END 

BEGIN 

  -- Add the job
  EXECUTE @ReturnCode = msdb.dbo.sp_add_job @job_id = @JobID OUTPUT , @job_name = N'Northwind Free Log Space', @owner_login_name = N'sa', @description = N'Job to run in response to error 9002. Backup the log. If that fails, truncate the log and then backup the database.', @category_name = N'[Uncategorized (Local)]', @enabled = 1, @notify_level_email = 0, @notify_level_page = 0, @notify_level_netsend = 0, @notify_level_eventlog = 3, @delete_level= 0
  IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback 

  -- Add the job steps
  EXECUTE @ReturnCode = msdb.dbo.sp_add_jobstep @job_id = @JobID, @step_id = 1, @step_name = N'Backup Log', @command = N'backup log northwind to disk = ''C:\Program Files\Microsoft SQL Server\MSSQL\Backup\Nwindlog.bak''', @database_name = N'master', @server = N'', @database_user_name = N'', @subsystem = N'TSQL', @cmdexec_success_code = 0, @flags = 2, @retry_attempts = 0, @retry_interval = 1, @output_file_name = N'C:\Program Files\Microsoft SQL Server\MSSQL\Backup\Nwlogbak.sql', @on_success_step_id = 0, @on_success_action = 1, @on_fail_step_id = 2, @on_fail_action = 4
  IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback 
  EXECUTE @ReturnCode = msdb.dbo.sp_add_jobstep @job_id = @JobID, @step_id = 2, @step_name = N'Truncate Log', @command = N'backup log northwind with truncate_only', @database_name = N'master', @server = N'', @database_user_name = N'', @subsystem = N'TSQL', @cmdexec_success_code = 0, @flags = 0, @retry_attempts = 0, @retry_interval = 1, @output_file_name = N'C:\Program Files\Microsoft SQL Server\MSSQL\Backup\Nwlogbak.sql', @on_success_step_id = 3, @on_success_action = 4, @on_fail_step_id = 0, @on_fail_action = 2
  IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback 
  EXECUTE @ReturnCode = msdb.dbo.sp_add_jobstep @job_id = @JobID, @step_id = 3, @step_name = N'Backup Database', @command = N'backup database northwind to disk = ''C:\Program Files\Microsoft SQL Server\MSSQL\Backup\Nwinddb.bak''', @database_name = N'master', @server = N'', @database_user_name = N'', @subsystem = N'TSQL', @cmdexec_success_code = 0, @flags = 2, @retry_attempts = 0, @retry_interval = 1, @output_file_name = N'C:\Program Files\Microsoft SQL Server\MSSQL\Backup\Nwlogbak.sql', @on_success_step_id = 0, @on_success_action = 1, @on_fail_step_id = 0, @on_fail_action = 2
  IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback 
  EXECUTE @ReturnCode = msdb.dbo.sp_update_job @job_id = @JobID, @start_step_id = 1 

  IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback 

  -- Add the Target Servers
  EXECUTE @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @JobID, @server_name = N'(local)' 
  IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback 

END
COMMIT TRANSACTION          
GOTO   EndSave              
QuitWithRollback:
  IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION 
EndSave: 
GO

/* Create alert on error 9002: Transaction Log Full */
IF (EXISTS 
   (SELECT name FROM msdb.dbo.sysalerts 
     WHERE name = N'Northwind 9002 Log Full'))
 ---- Delete the alert with the same name.
    EXECUTE msdb.dbo.sp_delete_alert 
    @name = N'Northwind 9002 Log Full' 
BEGIN 
  EXECUTE msdb.dbo.sp_add_alert 
  @name = N'Northwind 9002 Log Full', 
  @message_id = 9002, 
  @severity = 0, 
  @enabled = 1, 
  @delay_between_responses = 0, 
  @include_event_description_in = 5, 
  @database_name = N'Northwind', 
  @job_name = N'Northwind Free Log Space', 
  @category_name = N'[Uncategorized]'
END

GO