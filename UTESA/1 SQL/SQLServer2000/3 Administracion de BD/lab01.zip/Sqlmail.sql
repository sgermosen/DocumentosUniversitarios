/*
** Lab 5, Sqlmail.sql
** Modify this script to send an e-mail message to 
** yourself with the result set of a query. The 
** xp_sendmail extended stored procedure uses a 
** SQL Mail session to process the incoming 
** message and return the result set.
*/

USE master

EXEC xp_sendmail 'SQLAdminX@NWTraders.msft', 
@subject = 'Query Result: Total Products',
@query = 'select count(*) from northwind..products'