/*
** Lab 5, NWBackup.sql
** This script backs up the Northwind database.
*/


/* Backup Northwind database */
BACKUP DATABASE Northwind TO DISK = 'C:\Program Files\Microsoft SQL Server\MSSQL\Backup\Nwdb.bak'
WITH INIT
GO