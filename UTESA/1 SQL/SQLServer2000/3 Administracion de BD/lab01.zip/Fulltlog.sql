/*
** Lab 5, Fulltlog.sql
** This script is used to fill the Northwind transaction 
** log to test the performance condition alert.
*/

USE Northwind

WHILE 1 = 1
   BEGIN
      UPDATE Products
      SET ProductName = ProductName
      WAITFOR DELAY '000:00:00:999' --simulates a somewhat realistic OLTP environment
   END
