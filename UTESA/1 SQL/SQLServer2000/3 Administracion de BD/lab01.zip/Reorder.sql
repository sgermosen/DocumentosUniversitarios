/*
** Lab 5, Reorder.sql
** Stored procedure to test user-defined error
** message 50001 to set reorder inventory levels. 
*/

USE Northwind
GO

IF OBJECT_ID('dbo.ReOrder') IS NOT NULL --If the object already exists, drop it
   DROP PROCEDURE dbo.ReOrder
GO

CREATE PROC ReOrder @prodid int = null
AS

IF @prodid IS NULL
   BEGIN
      PRINT 'Enter a product #. For example: reorder 2'
      RETURN
   END

IF @prodid > (SELECT MAX(ProductID) FROM Products)
   BEGIN
      PRINT 'You must enter a valid product #'
      RETURN
   END

DECLARE @prodname nvarchar(40)
SET @prodname = 
   (SELECT ProductName FROM Products 
    WHERE ProductID = @prodid)

DECLARE @unitsinstock smallint
SET @unitsinstock = 
   (SELECT ReOrderLevel FROM Products 
    WHERE ProductID = @prodid)

UPDATE Products
SET UnitsInStock = @unitsinstock
WHERE ProductID = @prodid

RAISERROR (50001, 10, 1, @prodname, @unitsinstock)
