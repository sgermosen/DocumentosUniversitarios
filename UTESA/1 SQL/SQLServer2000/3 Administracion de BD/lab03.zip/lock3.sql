/*
Starts a transaction to read the Cusomers table in the ClassNorthwind database.
*/

USE ClassNorthwind

BEGIN TRAN
  SELECT * FROM Customers(TABLOCKX) WHERE CustomerID = 'GREAL'
-- For the purpose of the exercise, COMMIT TRAN or ROLLBACK TRAN are not used.

PRINT 'Server Process ID (spid)'
SELECT @@spid
-- Use the SPID to identify the connection when using sp_lock.
