/*
Read and update a record in the member table in library database.
*/

USE ClassNorthwind

SET TRANSACTION ISOLATION LEVEL SERIALIZABLE

BEGIN TRAN
  SELECT * FROM Customers WHERE CustomerID = 'GREAL'
  UPDATE Customers SET ContactName = 'Giovanni Rovelli' WHERE CustomerID = 'GREAL'
-- For the purpose of the exercise, COMMIT TRAN or ROLLBACK TRAN are not used.

PRINT 'Server Process ID (spid)'
SELECT @@spid
-- Use the SPID to identify the connection when using sp_lock.

-- ROLLBACK TRAN
