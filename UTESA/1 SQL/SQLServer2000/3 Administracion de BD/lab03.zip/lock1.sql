/*
Update a record in the Customers table in the ClassNorthwind database.
*/

USE ClassNorthwind

BEGIN TRAN
  UPDATE Customers
    SET ContactName = 'Howard Snyder'
    WHERE CustomerID ='GREAL'
-- For the purpose of the exercise, COMMIT TRAN or ROLLBACK TRAN are not used.

PRINT 'Server Process ID (spid)'
SELECT @@spid
-- Use the SPID to identify the connection when using sp_lock.