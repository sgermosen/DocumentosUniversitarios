/*
Starts a transaction to read the record of 
customer Great Lakes Food Market and update the contact name. 
Second select shows the uncommitted update. 
@@trancount shows the number of open transactions.
*/

USE ClassNorthwind


BEGIN TRAN
  PRINT 'trancount value:'
  SELECT @@trancount
  PRINT 'Before update:'
  SELECT ContactName FROM Customers WHERE CustomerID = 'GREAL'
  UPDATE Customers SET ContactName = 'Howard Snyder_Updated' WHERE CustomerID ='GREAL'
  PRINT 'After update:'
  SELECT ContactName FROM Customers WHERE CustomerID = 'GREAL'
  PRINT 'trancount value:'
  SELECT @@trancount
-- COMMIT TRANSACTION

SELECT ContactName FROM Customers WHERE CustomerID = 'GREAL'
