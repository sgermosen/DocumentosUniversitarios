/*
Starts a transaction to read the record of 
customer Great Lakes Food Market and update the contact name. 
Second SELECT shows the uncommitted update.
@@trancount showS the number of open transactions.
Then the transaction is rolled back and the record read again.
*/

USE ClassNorthwind


BEGIN TRAN
  PRINT 'trancount value:'
  SELECT @@trancount
  PRINT 'Before update:'
  SELECT ContactName FROM Customers WHERE CustomerID = 'GREAL'
  UPDATE Customers SET ContactName = 'Howard Snyder' WHERE CustomerID ='GREAL'
  PRINT 'After update:'
  SELECT ContactName FROM Customers WHERE CustomerID = 'GREAL'
  PRINT 'trancount value:'
  SELECT @@trancount

ROLLBACK TRAN

  Print 'ROLLBACK issued'
  SELECT ContactName FROM Customers WHERE CustomerID = 'GREAL'
  PRINT 'trancount value:'
  SELECT @@trancount
