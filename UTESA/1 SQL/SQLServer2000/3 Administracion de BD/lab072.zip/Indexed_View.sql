/*
**            Indexed_View.SQL
**
**  This script for lab 13, exercise 1 creates a view
**  called mem_charges on the charge table.
**  This view contains an aggregated column 
**  called charge_SUM.
**  Then it creates indexes on the view.
**  Finally it queries the charge table.
*/

USE credit
GO 

--Remove any existing indexes
EXEC index_cleanup charge

--Create a view on the charge table that 
--contains an aggregated colum
CREATE VIEW mem_charges 
WITH SCHEMABINDING 
AS
SELECT member_no, SUM(charge_amt) AS charge_SUM, COUNT_BIG(*) AS mem_count 
FROM dbo.charge GROUP BY member_no

--Create indexes on the view
CREATE UNIQUE CLUSTERED INDEX cl_mem_chg ON mem_charges(member_no)
CREATE NONCLUSTERED INDEX nc_mem_chg_amt ON mem_charges(Charge_SUM)

--Query the charge table. The query optimizer
--should use the nc_mem_chg_amt index to resolve the query
SELECT member_no, SUM(charge_amt) AS charge_SUM
FROM dbo.charge GROUP BY member_no

