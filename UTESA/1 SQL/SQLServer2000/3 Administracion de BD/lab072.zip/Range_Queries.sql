/*
**            Range_Queries.SQL
**
**  This script for lab 13, exercise 3 creates indexes 
**  and evaluates related query plans. 
*/

USE credit

-- Remove existing indexes
EXEC index_cleanup charge

-- Create a clustered index on the member_no column 
-- of the charge table
CREATE CLUSTERED INDEX charge_member_no_CL
   ON charge(member_no)

-- Turn statistics on
SET STATISTICS IO ON

--Retrieve member numbers 5001 to 6000
SELECT member_no 
FROM charge 
WHERE member_no BETWEEN 5001 AND 6000

-- Drop the clustered index and create a nonclustered index 
-- on the member_no column of the charge table
EXEC index_cleanup charge

CREATE NONCLUSTERED INDEX charge_member_no
   ON charge(member_no)

-- Retrieve member numbers 5001 to 6000
SELECT member_no 
FROM charge 
WHERE member_no
BETWEEN 5001 AND 6000

-- Drop existing indexes and create a clustered index 
-- on the member_no column of the charge table
EXEC index_cleanup charge

CREATE CLUSTERED INDEX charge_member_no_CL
   ON charge(member_no)

-- Retrieve all member numbers
SELECT member_no FROM charge

--Drop the clustered index and create a nonclustered index 
-- on the member_no column of the charge table
EXEC index_cleanup charge

CREATE NONCLUSTERED INDEX charge_member_no
   ON charge(member_no)

-- Retrieve all member numbers
SELECT member_no FROM charge
