/*
**            Hints.SQL
**
**  This script for lab 13, exercise 4 
**  forces the optimizer to select 
**  desired query plans.
*/


/*
** This section forces the use of an index
**
*/

USE credit

-- Drop existing indexes on the charge and member tables
EXEC index_cleanup charge

-- Create a clustered index on the charge_dt 
-- column of the charge table
CREATE CLUSTERED INDEX charge_date_CL
   ON charge(charge_dt)

-- Create a nonclustered index on the member_no 
-- column of the charge table
CREATE NONCLUSTERED INDEX charge_member_NC
   ON charge(member_no)

-- Retreive rows where the member_no equals 4000
SELECT * FROM charge 
WHERE member_no = 4000

-- Retreive rows where the member_no equals 4000
-- by forcing the use of the charge_date_CL index.
SELECT * FROM charge WITH(INDEX (charge_date_CL))
WHERE member_no = 4000


/* 
** This section forces a Join Plan
**
*/

-- Drop existing indexes on the charge and member tables
EXEC index_cleanup member

-- Create a clustered index on the member_no 
-- column of the member table
CREATE UNIQUE CLUSTERED INDEX member_no_CL
   ON member(member_no)

-- Join the charge and member tables
-- and examine the query plan
SELECT m.lastname, SUM(charge_amt) 
FROM charge AS c JOIN member AS m
   ON c.member_no = m.member_no
WHERE m.lastname = 'BARR'
GROUP BY m.lastname

-- Force a hash join
SELECT m.lastname, SUM(charge_amt) 
FROM charge AS c INNER HASH JOIN member AS m
   ON c.member_no = m.member_no
WHERE m.lastname = 'BARR'
GROUP BY m.lastname




SELECT * FROM charge