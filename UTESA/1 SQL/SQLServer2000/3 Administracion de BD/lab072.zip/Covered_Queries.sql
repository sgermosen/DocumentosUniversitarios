/*
**            Covered_Queries.SQL
**
**  This script for lab 13, exercise 2 creates indexes 
**  and evaluates related query plans. 
*/

USE credit
GO

-- Remove all existing indexes
EXEC index_cleanup charge

-- Create a clustered index on the member_no column 
-- of the charge table
CREATE CLUSTERED INDEX charge_member_no_CL
   ON charge(member_no)

-- Set the statistics option ON
SET STATISTICS IO ON

-- Retrieve all columns for member number 5001
SELECT * FROM charge WHERE member_no = 5001

-- Drop the clustered index and create a nonclustered index 
-- on the member_no column of the charge table
EXEC index_cleanup charge

CREATE NONCLUSTERED INDEX charge_member_no
   ON charge(member_no)

--Retrieve all columns for member number 5001
SELECT * FROM charge WHERE member_no = 5001

-- Drop existing indexes and create a clustered index 
-- on the member_no column of the charge table
EXEC index_cleanup charge

CREATE CLUSTERED INDEX charge_member_no_CL
   ON charge(member_no)

-- Retrieve only the member_no column for member number 5001
SELECT member_no FROM charge WHERE member_no = 5001

-- Drop the clustered index and create a nonclustered index 
-- on the member_no column of the charge table
EXEC index_cleanup charge

CREATE NONCLUSTERED INDEX charge_member_no
   ON charge(member_no)

-- Retrieve only the member_no column for member number 5001
SELECT member_no FROM charge WHERE member_no = 5001
