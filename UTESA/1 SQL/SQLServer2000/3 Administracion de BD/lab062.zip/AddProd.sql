/*
** Lab 7, AddProd.sql
** This script adds a new item to the product table
** in the NWCOPY database.
*/

USE NWCOPY
GO

INSERT  products(productID,ProductName,SupplierID,CategoryID,QuantityPerUnit,
UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued)
Values(150,'Maple Flavor Pancake Mix',15,0,'12 per case',1.27,5,5,1,0)


SELECT * FROM products WHERE ProductName = 'Maple Flavor Pancake Mix'

