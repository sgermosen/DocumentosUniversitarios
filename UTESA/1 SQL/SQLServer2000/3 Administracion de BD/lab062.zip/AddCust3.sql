/*
** Lab 7, AddCust3.sql
** This script add a new customer to Nwcopy.customer
*/

USE NWCOPY
GO

INSERT INTO CUSTOMERS(CustomerID, CompanyName, ContactName)
VALUES('THEWI', 'The Wine Cellar', 'Michael Holz')


SELECT * FROM customers where customerid = 'THEWI'


