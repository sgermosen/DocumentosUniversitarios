/*
** Lab 7, AddCust2.sql
** This script add a new customer to Nwcopy.customer
*/

USE NWCOPY
GO

INSERT INTO CUSTOMERS(CustomerID, CompanyName, ContactName)
VALUES('VOLCA', 'Volcano Coffee Company', 'Paula Wilson')


SELECT * FROM customers WHERE customerid = 'VOLCA'


