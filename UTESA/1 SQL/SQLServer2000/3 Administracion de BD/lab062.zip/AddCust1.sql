/*
** Lab 7, AddCust1.sql
** This script add a new customer to Nwcopy.customer
*/

USE NWCOPY
GO

INSERT INTO CUSTOMERS(CustomerID, CompanyName, ContactName)
VALUES('HEALT', 'Health Food Store', 'Mike Nash')


SELECT * FROM customers where customerid = 'HEALT'

