/*
** Lab 7, LogBack1.sql
** This script creates a new permanent backup device - NWCHANGE
** and backs up the log of the Nwcopy database.
*/

---Create the backup device
USE MASTER
GO

sp_addumpdevice 'disk', 'NWCHANGE', 'C:\BACKUP\NWCHANGE.bak'

---Backup the Log
BACKUP LOG Nwcopy TO NWCHANGE 
WITH FORMAT, NAME = 'NWC Changes', DESCRIPTION = 'Log and Differential backups of Nwcopy'



