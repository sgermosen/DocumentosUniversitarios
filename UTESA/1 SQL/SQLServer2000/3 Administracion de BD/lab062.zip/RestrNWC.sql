/*
** Lab 7, RestrNWC.sql
** This script restores and recovers the NWCOPY database.
** The existing database is overwritten.
*/

USE MASTER
GO

---set the database to single user mode
sp_dboption 'NWCOPY', 'single user', true

---Restore the database, overwrite existing copy and recover.
RESTORE DATABASE NWCOPY FROM NWC2
WITH REPLACE, RECOVERY

---Turn single user mode off
sp_dboption 'NWCOPY', 'single user', false

---Confirm that the data was recovered
USE NWCopy
GO
SELECT * FROM products