/*
** Lab 7, FullBack.sql
** This script creates a new permanent backup device - NWC3
** and performs a full database backup of Nwcopy to that device.
*/


---create the NWC3 device
USE Master
GO

sp_addumpdevice 'disk','NWC3','C:\BACKUP\NWC3.bak'
go


---perform a full DB backup

BACKUP DATABASE Nwcopy to NWC3 
WITH FORMAT, NAME = 'Nwcopy Full', Description = 'A full DB backup of Nwcopy'