/*
** Lab 7, SetupNWC.sql
** This script installs a copy of the NWCopy database on the local 
** SQL Server. A copy of the file NWC1.bak must be copied from the student cd
** to C:\BACKUP\NWC1.bak before executing this script.
**/

USE master 
GO

RESTORE DATABASE NWCOPY FROM DISK = 'C:\Backup\NWC1.bak'
WITH REPLACE, RECOVERY

EXEC sp_dboption 'nwcopy', 'single user', 'FALSE'