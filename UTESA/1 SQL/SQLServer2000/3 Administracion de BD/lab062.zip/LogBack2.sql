/*
** Lab 7, LogBack2.sql
** This script backs up the log of the Nwcopy database and
** appends the backup to the NWCHANGE device.
*/

USE Master
GO

---Backup the Log
BACKUP LOG Nwcopy TO NWCHANGE 
WITH NOINIT



