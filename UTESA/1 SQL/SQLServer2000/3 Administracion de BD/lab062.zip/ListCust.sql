/*
** Lab 7, ListCust.sql
** This script check to see if three additions to 
** the customers table have been recovered by the 
** restore process.
*/


USE NWCOPY

SELECT * FROM customers 
WHERE customerid IN ('VOLCA', 'HEALT','THEWI')
