/*
** Lab 7, DiffBack.sql
** This script performs a differential backup of the Nwcopy database.
** The backup is appended to the NWCHANGE device
*/

USE MASTER
GO

---Backup the changes since the last full database backup
BACKUP DATABASE Nwcopy to NWCHANGE 
with DIFFERENTIAL, NOINIT



