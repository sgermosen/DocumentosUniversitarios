/*
** Lab 7, DataLoss.sql
** This script damages the products table with a 
** poorly written UPDATE statement
*/

USE NWCOPY
GO

UPDATE products SET productname = 'Nut Crunch Cookies'


---Verify that all product names were changed
SELECT * FROM products WHERE productname = 'Maple Flavor Pancake Mix'