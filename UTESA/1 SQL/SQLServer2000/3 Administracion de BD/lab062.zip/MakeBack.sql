/*
** Lab 7, MakeBack.sql
** This script backs up the NWCOPY database to a single file
** with a logical name of NWC2. The physical file is created in
** C:\BACKUP\NWC2.bak
*/

--- Create a backup device
USE MASTER
GO

sp_addumpdevice 'disk', 'NWC2','c:\backup\NWC2.bak'

---Backup the database

BACKUP DATABASE NWCOPY to NWC2 
WITH FORMAT, NAME = 'NWCOPY-Full',
DESCRIPTION = 'A single file full backup of NWCOPY'


