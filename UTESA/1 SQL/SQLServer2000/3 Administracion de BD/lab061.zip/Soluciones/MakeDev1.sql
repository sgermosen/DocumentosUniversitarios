/*
** Lab 6, MakeDev1.sql
** This script creates two permanent disk backup files 
** and reflects the action taken by 
** using Enterprise Manager to create the devices.
*/

/* Create some logical backup devices */

USE master
EXEC sp_addumpdevice 'disk', 'Nw1', 'C:\Backup\Nw1.bak' 
EXEC sp_addumpdevice 'disk', 'Nwlog', 'C:\Backup\Nwlog.bak' 