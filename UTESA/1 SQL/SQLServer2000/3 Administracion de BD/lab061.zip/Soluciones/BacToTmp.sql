/*
** Lab 6, BacToTmp.sql
** Creating a new backup device while 
** performing a backup.
*/

BACKUP DATABASE Northwind TO DISK = 'C:\Backup\MyNewBackup.bak'
WITH FORMAT ,
DESCRIPTION = 'New temporary backup device, not recorded in system tables'