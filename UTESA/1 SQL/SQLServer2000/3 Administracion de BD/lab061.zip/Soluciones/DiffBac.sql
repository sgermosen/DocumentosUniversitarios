/*
** Lab 6, DiffBac.sql
** Perform an differential backup of Northwind.
*/

BACKUP DATABASE Northwind TO DISK = 'C:\Backup\Nwdiff.bak'
WITH NOINIT, DIFFERENTIAL