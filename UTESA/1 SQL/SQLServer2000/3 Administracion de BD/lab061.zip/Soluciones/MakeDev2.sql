/*
** Lab 6, MakeDev2.sql
** This script creates two permanent disk backup files 
*/

/* Create some logical backup devices */

USE master

EXEC sp_addumpdevice 'disk', 'Nwstripe1', 'C:\Backup\Nwstripe1.bak' 
EXEC sp_addumpdevice 'disk', 'Nwstripe2', 'C:\Backup\Nwstripe2.bak'