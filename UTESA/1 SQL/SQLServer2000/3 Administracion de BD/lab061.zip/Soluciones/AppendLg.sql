/*
** Lab 6, AppendLg.sql
** Append a new log backup to a backup file.
*/


BACKUP LOG Northwind TO Nwlog
WITH NOINIT