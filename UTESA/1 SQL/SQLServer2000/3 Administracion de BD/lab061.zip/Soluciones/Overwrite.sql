/*
** Lab 6, Overwrite.sql
** Overwrite an existing backup file with a new backup.
*/


BACKUP DATABASE Northwind to Nw1
WITH INIT ,
DESCRIPTION = 'The third full backup of Northwind overwrites all others'