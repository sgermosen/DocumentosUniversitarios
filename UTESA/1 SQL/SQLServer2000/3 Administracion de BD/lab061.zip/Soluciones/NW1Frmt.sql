/*
** Lab 6, NW1Frmt.sql
** Backup the Northind database to the logical device Nw1 
*/


Use Master
BACKUP DATABASE Northwind TO Nw1 
WITH FORMAT, DESCRIPTION = 'The first full backup of Northwind',
NAME = 'NorthwindFull'