/*
** Lab 6, Stripe.sql
** Create a backup on multiple devices.
*/

BACKUP DATABASE Northwind TO Nwstripe1, Nwstripe2
WITH FORMAT,
DESCRIPTION = 'A parallel backup of Northwind',
NAME = 'stripeNW'