/*
** Lab 6, Append.sql
** Append a new backup to an existing device
*/

BACKUP DATABASE Northwind to Nw1
WITH NOINIT ,
DESCRIPTION = 'The second full backup of Northwind'