/*
** Lab 6, BacLog.sql
** This script backs up the log and overwrites
** the backup file contents
*/

BACKUP LOG Northwind TO nwlog
WITH INIT