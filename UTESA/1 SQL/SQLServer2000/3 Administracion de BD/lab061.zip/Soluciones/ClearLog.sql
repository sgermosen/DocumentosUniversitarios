/*
** Lab 6, ClearLog.sql
** Clear the log and then back up the database.
*/

BACKUP LOG Northwind
WITH TRUNCATE_ONLY

BACKUP DATABASE Northwind TO Nw1 
WITH NOINIT