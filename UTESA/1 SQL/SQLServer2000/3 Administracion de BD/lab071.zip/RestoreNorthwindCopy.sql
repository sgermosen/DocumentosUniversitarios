/*
** Lab 8, RestoreNorthwindCopy.sql
** This script restores the NorthwindCopy database to your server.
*/

USE master 
GO

RESTORE DATABASE NorthwindCopy FROM DISK = 'C:\MOC\2072a\Labfiles\L08\NorthwindCopy.bak'
WITH REPLACE, RECOVERY