/*
** Lab 8, Lock.SQL
** Starts a transaction to read and update a record in the
** member table in the NorthwindCopy database.
** The transaction deliberately does not issue a COMMIT TRAN   
** or ROLLBACK TRAN in order to hold the locks on the server.
** The server process id (spid) for the connection is displayed
** to help identify the connection when using sp_lock.
*/

USE NorthwindCopy

BEGIN TRAN
  UPDATE Employees
    SET LastName = 'SMITH'
    WHERE EmployeeID =1

exec sp_lock



