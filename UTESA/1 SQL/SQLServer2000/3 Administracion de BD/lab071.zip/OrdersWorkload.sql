/*
** Lab 8, OrdersWorkload.sql
** This file runs several queries.
** Use SQL Profiler to determine which is the 
** longest running.
*/
USE NorthwindCopy
GO

SELECT * FROM Customers
GO

---
SELECT CompanyName,ContactName,ContactTitle
FROM Customers
WHERE CustomerID LIKE 'F%'
GO

---
SELECT FirstName, LastName, Extension
FROM Employees
WHERE EmployeeID = 1
GO

---
SELECT ProductName, UnitPrice
FROM Products
WHERE ProductID = 1
GO

---
SELECT Companyname, Phone 
FROM Shippers
WHERE ShipperID = 1
GO

---
SELECT c.CompanyName, p.ProductName, SUM(d.Quantity * d.UnitPrice) 
FROM Customers c JOIN Orders o ON c.CustomerID = o.CustomerID
JOIN [Order Details] d ON o.OrderID = d.OrderID
JOIN Products p ON d.ProductID = p.ProductID
WHERE p.ProductID in (5, 11, 12) 
GROUP BY c.CompanyName, p.ProductName
GO

---
SELECT e.LastName, p.ProductName, SUM(d.Quantity * d.UnitPrice) 
FROM Employees e JOIN Orders o ON e.EmployeeID = o.EmployeeID
JOIN [Order Details] d ON o.OrderID = d.OrderID
JOIN Products p ON d.ProductID = p.ProductID
GROUP BY e.LastName, p.ProductName
GO

---
SELECT e.LastName, p.ProductName, AVG(d.Quantity * d.UnitPrice) 
FROM Employees e JOIN Orders o ON e.EmployeeID = o.EmployeeID
JOIN [Order Details] d ON o.OrderID = d.OrderID
JOIN Products p ON d.ProductID = p.ProductID
GROUP BY e.LastName, p.ProductName
GO

---
SELECT p.ProductName, SUM(d.Quantity * d.UnitPrice) 
FROM [Order Details] d JOIN Products p
ON d.ProductID =  p.ProductID 
GROUP BY p.ProductName
GO

---
SELECT e.LastName, e.FirstName, COUNT(o.OrderID)
FROM Employees e JOIN Orders o
ON e.EmployeeID = o.EmployeeID
GROUP BY e.LastName, e.FirstName
GO

---
EXEC sp_help 
GO
