/*
**    Lab 3, Creasmpl.sql
Creates a database using Transact-SQL.
*/

CREATE DATABASE SampleDBTsql
ON PRIMARY 
  (
  NAME= SampleDBTsql_Data, 
  FILENAME='C:\Program Files\Microsoft SQL Server\MSSQL\Data\SampleDBTsql_Data.mdf', 
  SIZE=7MB,
  FILEGROWTH=3MB)
LOG ON 
  (
  NAME= SampleDBTsql_Log, 
  FILENAME='C:\Program Files\Microsoft SQL Server\MSSQL\Data\SampleDBTsql_Log.ldf', 
  SIZE=3MB,
  MAXSIZE=10MB,
  FILEGROWTH=1MB
  )
GO
