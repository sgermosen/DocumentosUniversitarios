/*
**  Lab 3, Dropdb.sql
**  Drop SampleDBTsql and SampleDBWizard databases and view list of databases. 
*/

USE master
DROP DATABASE SampleDBTsql, SampleDBWizard
GO

EXEC sp_helpdb
GO

