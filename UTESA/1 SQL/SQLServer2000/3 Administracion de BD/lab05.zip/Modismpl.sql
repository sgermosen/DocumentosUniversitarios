/*
**    Lab 3, Modismpl.sql
Modifies the SampleDBTsql database using Transact-SQL.
*/

ALTER DATABASE SampleDBTsql
  MODIFY FILE
  (NAME = 'SampleDBTsql_Log',
   MAXSIZE=20MB)
GO

