--*********************************************************************
-- 2317B Pr�ctica 7A:  Modificaci�n de datos
--       EJERCICIO 3:  Uso de la instrucci�n INSERT con la palabra 
--                     clave DEFAULT VALUES
--     PROCEDIMIENTO:  Para crear la tabla Sample1
-----------------------------------------------------------------------

USE LIBRARY
CREATE TABLE sample1 (
     Cust_id    int       NOT NULL  IDENTITY(100,5)
    ,Name       char(10)  NULL
    ) 
GO
	
