--*********************************************************************
-- 2317B Pr�ctica 7A:  Modificaci�n de datos
--       EJERCICIO 6:  Modificaci�n de tablas basada en los datos de 
--                     otras tablas
--     PROCEDIMIENTO:  Para agregar un nuevo miembro joven a la base 
--                     de datos
-----------------------------------------------------------------------

/*
**	Esta secuencia de comandos agrega un nuevo miembro joven 
**	mediante la inserci�n de una fila en la tabla Member, seguida
**	de una inserci�n en la tabla Juvenile.
**
*/

USE library

BEGIN TRANSACTION

 SET IDENTITY_INSERT member ON

 INSERT member (member_no, lastname, firstname, middleinitial)
  VALUES ( 16101, 'Walters', 'B.', 'L' )

 SET IDENTITY_INSERT member OFF

 INSERT juvenile
  VALUES ( 16101, 1, DATEADD(YY, -18, DATEADD(DD, -1, GETDATE())) )

COMMIT TRANSACTION

