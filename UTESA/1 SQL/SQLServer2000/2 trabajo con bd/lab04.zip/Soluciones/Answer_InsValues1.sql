--*********************************************************************
-- 2317B Pr�ctica 7A:  Modificaci�n de datos
--       EJERCICIO 1:  Uso de la instrucci�n INSERT
--     PROCEDIMIENTO:  Insertar valores en la tabla Item
-----------------------------------------------------------------------

USE library
INSERT item (isbn, title_no, cover, loanable, translation)
 VALUES (10001, 8, 'HARDBACK', 'Y', 'ENGLISH')
INSERT item (isbn, title_no, cover, loanable, translation)
 VALUES (10101, 8, 'SOFTBACK', 'Y', 'ENGLISH') 
GO
	
