--*********************************************************************
-- 2317B Pr�ctica 7A:  Modificaci�n de datos
--       EJERCICIO 6:  Modificaci�n de tablas basada en los datos de 
--                     otras tablas
--     PROCEDIMIENTO:  Para eliminar filas de la tabla Juvenile que
--                     coinciden en la tabla Adult
-----------------------------------------------------------------------

USE library
DELETE juvenile
 FROM juvenile
 INNER JOIN adult
  ON juvenile.member_no = adult.member_no
GO
