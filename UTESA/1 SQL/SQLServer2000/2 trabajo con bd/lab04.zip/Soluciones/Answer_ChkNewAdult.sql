--*********************************************************************
-- 2317B Pr�ctica 7A:  Modificaci�n de datos
--       EJERCICIO 6:  Modificaci�n de tablas basada en los datos de 
--                     otras tablas
--     PROCEDIMIENTO:  Para comprobar que un registro de Juvenile 
--                     determinado se agreg� a la tabla Adult
-----------------------------------------------------------------------

USE library
SELECT *
 FROM adult
 WHERE member_no = 16101
GO
