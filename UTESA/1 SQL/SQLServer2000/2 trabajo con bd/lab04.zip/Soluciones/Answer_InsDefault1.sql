--*********************************************************************
-- 2317B Pr�ctica 7A:  Modificaci�n de datos
--       EJERCICIO 2:  Uso de la instrucci�n INSERT con la palabra 
--                     clave DEFAULT
--     PROCEDIMIENTO:  Para insertar valores en la tabla Title
-----------------------------------------------------------------------

USE library
INSERT title (title, author, synopsis)
 VALUES ('The Art of Lawn Tennis', 'William T. Tilden'
         ,DEFAULT ) 
GO
	
