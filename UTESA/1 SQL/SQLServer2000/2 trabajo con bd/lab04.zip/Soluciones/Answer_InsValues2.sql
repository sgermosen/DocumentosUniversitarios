--*********************************************************************
-- 2317B Pr�ctica 7A:  Modificaci�n de datos
--       EJERCICIO 1:  Uso de la instrucci�n INSERT
--     PROCEDIMIENTO:  Insertar valores en la tabla Copy
-----------------------------------------------------------------------

USE library
INSERT copy (isbn, copy_no, title_no, on_loan)
 VALUES (10001,1,8,'N') 
GO
	
