--*********************************************************************
-- 2317B Pr�ctica 7A:  Modificaci�n de datos
--       EJERCICIO 1:  Uso de la instrucci�n INSERT
--     PROCEDIMIENTO:  Determinar el idioma de traducci�n de un 
--                     elemento
-----------------------------------------------------------------------

USE library
SELECT translation
 FROM item
 WHERE isbn = 10001
GO
	
