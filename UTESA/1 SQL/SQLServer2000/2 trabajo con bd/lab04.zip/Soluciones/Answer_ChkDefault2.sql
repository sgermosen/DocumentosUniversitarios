--*********************************************************************
-- 2317B Pr�ctica 7A:  Modificaci�n de datos
--       EJERCICIO 3:  Uso de la instrucci�n INSERT con la palabra 
--                     clave DEFAULT VALUES
--     PROCEDIMIENTO:  Para comprobar que los valores se han insertado 
--                     en la tabla Sample1
-----------------------------------------------------------------------

USE LIBRARY
SELECT *
 FROM sample1
GO
	
