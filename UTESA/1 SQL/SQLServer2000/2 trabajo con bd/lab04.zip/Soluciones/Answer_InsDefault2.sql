--*********************************************************************
-- 2317B Pr�ctica 7A:  Modificaci�n de datos
--       EJERCICIO 3:  Uso de la instrucci�n INSERT con la palabra 
--                     clave DEFAULT VALUES
--     PROCEDIMIENTO:  Para insertar una fila de valores 
--                     predeterminados en la tabla Sample1
-----------------------------------------------------------------------

USE LIBRARY
INSERT sample1
 DEFAULT VALUES
GO
	
