--*********************************************************************
-- 2317B Pr�ctica 7A:  Modificaci�n de datos
--       EJERCICIO 5:  Uso de la instrucci�n UPDATE
--     PROCEDIMIENTO:  Para actualizar una fila de datos espec�fica de 
--                     la tabla Member
-----------------------------------------------------------------------

USE library
UPDATE member
 SET lastname = 'BENSON'
 WHERE member_no = 507
GO
	
