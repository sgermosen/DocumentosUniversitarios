--*********************************************************************
-- 2317B Pr�ctica 7A:  Modificaci�n de datos
--       EJERCICIO 4:  Uso de la instrucci�n DELETE
--     PROCEDIMIENTO:  Para recuperar una fila de datos que se propone
--                     eliminar de la tabla Item
-----------------------------------------------------------------------

USE library
SELECT *
 FROM item
 WHERE isbn = 10101
  AND  title_no = 8
GO
	
