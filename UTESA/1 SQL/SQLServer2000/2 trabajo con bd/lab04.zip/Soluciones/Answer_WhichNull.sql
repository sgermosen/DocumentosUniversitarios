--*********************************************************************
-- 2317B Pr�ctica 7A:  Modificaci�n de datos
--       EJERCICIO 2:  Uso de la instrucci�n INSERT con la palabra 
--                     clave DEFAULT
--     PROCEDIMIENTO:  Para determinar las columnas que permiten 
--                     valores NULL
-----------------------------------------------------------------------

USE library
EXEC sp_help title
GO
	
