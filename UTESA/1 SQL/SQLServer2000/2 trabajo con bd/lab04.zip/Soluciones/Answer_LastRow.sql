--*********************************************************************
-- 2317B Pr�ctica 7A:  Modificaci�n de datos
--       EJERCICIO 2:  Uso de la instrucci�n INSERT con la palabra 
--                     clave DEFAULT
--     PROCEDIMIENTO:  Para recuperar la �ltima fila insertada en la 
--                     tabla Title
-----------------------------------------------------------------------

USE library
SELECT *
 FROM title
 WHERE title_no = @@identity
GO
	
