--*********************************************************************
-- 2317B Pr�ctica 7A:  Modificaci�n de datos
--       EJERCICIO 6:  Modificaci�n de tablas basada en los datos de 
--                     otras tablas
--     PROCEDIMIENTO:  Para comprobar que ciertos registros se
--                     quitaron de la tabla Juvenile
-----------------------------------------------------------------------

USE library
SELECT *
 FROM juvenile
 WHERE member_no = 16101
GO
