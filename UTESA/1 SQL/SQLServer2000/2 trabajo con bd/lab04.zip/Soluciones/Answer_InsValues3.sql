--*********************************************************************
-- 2317B Pr�ctica 7A:  Modificaci�n de datos
--       EJERCICIO 2:  Uso de la instrucci�n INSERT con la palabra 
--                     clave DEFAULT
--     PROCEDIMIENTO:  Para insertar m�s valores en la tabla Title
-----------------------------------------------------------------------

USE library
INSERT title (title, author)
 VALUES ('Riders of the Purple Sage', 'Zane Grey') 
GO
	
