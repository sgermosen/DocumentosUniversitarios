--*********************************************************************
-- 2317B Pr�ctica 7A:  Modificaci�n de datos
--       EJERCICIO 6:  Modificaci�n de tablas basada en los datos de 
--                     otras tablas
--     PROCEDIMIENTO:  Para determinar los registros que se deben mover
--                     de la tabla Juvenile a la tabla Adult
-----------------------------------------------------------------------

USE library
 SELECT ju.member_no, ad.street, ad.city, ad.state
       ,ad.zip, ad.phone_no, DATEADD( YY, 1, GETDATE() )
 FROM juvenile AS ju 
 INNER JOIN adult AS ad
  ON ju.adult_member_no = ad.member_no
 WHERE ( DATEADD(YY, 18, ju.birth_date) < GETDATE() )
GO
