--*********************************************************************
-- 2317B Pr�ctica 7A:  Modificaci�n de datos
--       EJERCICIO 4:  Uso de la instrucci�n DELETE
--     PROCEDIMIENTO:  Para eliminar una fila de datos espec�fica de 
--                     la tabla Item
-----------------------------------------------------------------------

USE library
DELETE FROM item
 WHERE isbn = 10101
  AND  title_no = 8
GO
	
