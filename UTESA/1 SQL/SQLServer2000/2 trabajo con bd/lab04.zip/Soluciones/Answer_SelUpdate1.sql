--*********************************************************************
-- 2317B Pr�ctica 7A:  Modificaci�n de datos
--       EJERCICIO 5:  Uso de la instrucci�n UPDATE
--     PROCEDIMIENTO:  Para recuperar una fila de datos que se propone
--                     actualizar de la tabla Member
-----------------------------------------------------------------------

USE library
SELECT *
 FROM member
 WHERE member_no = 507
GO
	
