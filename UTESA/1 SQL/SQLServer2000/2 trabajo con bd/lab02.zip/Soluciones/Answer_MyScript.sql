--*********************************************************************
-- 2317B Pr�ctica 2A:  Creaci�n y ejecuci�n de secuencias de comandos 
--                     de Transact-SQL
--       EJERCICIO 2:  Modificar un archivo de comandos
--     PROCEDIMIENTO:  Para modificar un archivo de comandos
-----------------------------------------------------------------------

/*
            MYSCRIPT.SQL

  Esta secuencia de comandos consulta la tabla Customer y devuelve una 
  lista de nombres de compa��as. Esta secuencia de comandos se debe 
  ejecutar en la base de datos Northwind.
*/
USE northwind

SELECT CompanyName FROM customers
GO
