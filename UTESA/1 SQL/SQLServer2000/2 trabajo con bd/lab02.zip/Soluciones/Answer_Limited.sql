--*********************************************************************
-- 2317B Pr�ctica 2A:  Creaci�n y ejecuci�n de secuencias de comandos 
--                     de Transact-SQL
--       EJERCICIO 1:  Escribir instrucciones SELECT b�sicas
--     PROCEDIMIENTO:  Para escribir una instrucci�n SELECT que 
--                     devuelva datos limitados
-----------------------------------------------------------------------

SELECT * FROM products WHERE categoryid = 4
