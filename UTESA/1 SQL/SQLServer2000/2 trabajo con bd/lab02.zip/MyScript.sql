            MYSCRIPT.SQL

  Esta secuencia de comandos consulta la tabla Customer y devuelve 
  una lista de nombres de compa��as. Esta secuencia de comandos se 
  debe ejecutar en la base de datos Northwind.
