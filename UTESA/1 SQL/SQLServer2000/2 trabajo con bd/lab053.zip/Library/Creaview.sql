/*
Esta secuencia de comandos crea todas las VISTAS de la base de datos Library.
*/

USE library
GO

/* Si ya existen los objetos (por ejemplo, si esto es una reconstrucci�n), b�rrelos. */

IF EXISTS ( SELECT table_name FROM information_schema.views
            WHERE table_name = 'AdultwideView' )
     DROP VIEW AdultwideView

IF EXISTS ( SELECT table_name FROM information_schema.views
            WHERE table_name = 'ChildwideView' )
     DROP VIEW ChildwideView

IF EXISTS ( SELECT table_name FROM information_schema.views
            WHERE table_name = 'CopywideView' )
     DROP VIEW CopywideView

IF EXISTS ( SELECT table_name FROM information_schema.views
            WHERE table_name = 'LoanableView' )
     DROP VIEW LoanableView

IF EXISTS ( SELECT table_name FROM information_schema.views
            WHERE table_name = 'OnshelfView' )
     DROP VIEW OnshelfView

IF EXISTS ( SELECT table_name FROM information_schema.views
            WHERE table_name = 'OnloanView' )
     DROP VIEW OnloanView

IF EXISTS ( SELECT table_name FROM information_schema.views
            WHERE table_name = 'OverdueView' )
     DROP VIEW OverdueView
GO



/*
Crea las vistas para la base de datos Library.
*/

/* 
AdultwideView: consulta las tablas Member y Adult.  
Enumera el nombre y la direcci�n de todos los adultos. 
*/

CREATE VIEW dbo.AdultwideView
AS
SELECT	adult.member_no,
	member.lastname,
	member.firstname,
	member.middleinitial,
	adult.street,
	adult.city,
	adult.state,
	adult.zip,
	adult.phone_no,
	adult.expr_date
FROM adult
JOIN member
ON adult.member_no = member.member_no 
GO

/* 
ChildwideView: consulta las tablas Member, Adult y Juvenile.  
Enumera el nombre y la direcci�n de todos los juveniles.
*/

CREATE VIEW dbo.ChildwideView
AS
SELECT 
	juvenile.member_no,
	member.lastname,
	member.firstname,
	member.middleinitial,
	adult.street,
	adult.city,
	adult.state,
	adult.zip,
	adult.phone_no,
	adult.expr_date
FROM juvenile
JOIN member
ON member.member_no = juvenile.member_no
JOIN adult
ON adult.member_no = juvenile.adult_member_no 
GO


/*
CopywideView: consulta las tablas Copy, Title e Item.  
Enumera la informaci�n completa acerca de cada copia.
*/

CREATE VIEW dbo.CopywideView
AS
SELECT 
	copy.isbn,
	copy.copy_no,
	title.title,
	title.author,
	item.translation,
	item.loanable,
	copy.on_loan
FROM copy
JOIN item
ON item.isbn = copy.isbn
JOIN title
ON title.title_no = copy.title_no
GO


/*
LoanableView: consulta CopywideView (uni�n de 3 tablas).  
Enumera la informaci�n completa acerca de cada copia marcada como que se puede prestar.
*/

CREATE VIEW dbo.LoanableView
AS
SELECT *
FROM CopywideView
WHERE loanable = 'Y'
GO

/* 
OnshelfView: consulta CopywideView (uni�n de 3 tablas).
Enumera informaci�n completa acerca de cada copia que est� actualmente prestada.
*/

CREATE VIEW dbo.OnshelfView
AS
    SELECT *
    FROM CopywideView
    WHERE on_loan ='N'
GO


/*
OnloanView: consulta las tablas Loan, Title y Member.
Enumera informaci�n acerca del miembro, t�tulo y pr�stamo de una copia que est� actualmente prestada.  
*/

CREATE VIEW dbo.OnloanView
AS
SELECT
	loan.isbn,
	loan.copy_no,
	loan.title_no,
	title.title,
	title.author,
	loan.member_no,
	member.lastname,
	member.firstname,
	loan.out_date,
	loan.due_date
FROM loan
JOIN title
ON title.title_no = loan.title_no
JOIN member
ON member.member_no = loan.member_no
GO


/*
OverdueView: consulta OnLoanView. (Uni�n de 3 tablas.)
Enumera informaci�n acerca del miembro, t�tulo y pr�stamo de una copia que est� atrasada. 
*/

CREATE VIEW dbo.OverdueView
AS
SELECT *
FROM OnloanView
WHERE OnloanView.due_date < GETDATE()
GO


/* Muestra el resultado. */

PRINT 'VIEWS CREATED'
SELECT table_name
FROM information_schema.views
WHERE table_schema = 'dbo'
AND table_name not like 'sys%'
ORDER BY table_name
GO
