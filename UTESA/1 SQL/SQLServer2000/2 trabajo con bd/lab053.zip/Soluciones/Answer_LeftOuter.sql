--*********************************************************************
-- 2317B Pr�ctica 5A:  Consultas a varias tablas
--       EJERCICIO 1:  Combinaci�n de tablas
--     PROCEDIMIENTO:  Para combinar varias tablas mediante una 
--                     combinaci�n externa
-----------------------------------------------------------------------

USE library
SELECT me.member_no
      ,me.lastname + ', ' + me.firstname + ' '
        + me.middleinitial AS name
      ,re.isbn
      ,CONVERT(char(8),re.log_date,1) AS date
 FROM member AS me
 LEFT OUTER JOIN reservation AS re 
  ON me.member_no = re.member_no
 WHERE me.member_no IN ( 250, 341, 1675 )
 ORDER BY me.member_no
GO
	
