--*********************************************************************
-- 2317B Pr�ctica 5A:  Consultas a varias tablas
--       EJERCICIO 2:  Uso del operador UNION para combinar conjuntos 
--                     de resultados
--     PROCEDIMIENTO:  Para determinar los miembros que viven en 
--                     California que tienen m�s de tres hijos con 
--                     carnet de biblioteca
-----------------------------------------------------------------------

USE library
SELECT a.member_no
      ,count(*) AS numkids
 FROM juvenile AS j
 INNER JOIN adult AS a
  ON  j.adult_member_no = a.member_no
 WHERE a.state = 'CA'
 GROUP BY a.member_no
 HAVING COUNT(*) > 3
GO
	
