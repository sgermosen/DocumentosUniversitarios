--*********************************************************************
-- 2317B Pr�ctica 5A:  Consultas a varias tablas
--       EJERCICIO 1:  Combinaci�n de tablas
--     PROCEDIMIENTO:  Para crear una lista de correo mediante una 
--                     combinaci�n
-----------------------------------------------------------------------

USE library
SELECT firstname + ' ' + middleinitial + ' ' + lastname AS name
      ,street, city, state, zip 
 FROM member
 INNER JOIN adult
  ON member.member_no = adult.member_no
GO 
	
