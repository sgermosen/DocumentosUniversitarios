--*********************************************************************
-- 2317B Pr�ctica 5A:  Consultas a varias tablas
--       EJERCICIO 1:  Combinaci�n de tablas
--     PROCEDIMIENTO:  Para combinar varias tablas y ordenar los 
--                     resultados
-----------------------------------------------------------------------

USE library
SELECT co.isbn, co.copy_no, co.on_loan
      ,ti.title, it.translation, it.cover 
 FROM copy co
 INNER JOIN title AS ti
  ON co.title_no = ti.title_no 
 INNER JOIN item AS it 
  ON co.isbn = it.isbn 
 WHERE co.isbn IN ( 1, 500, 1000) 
 ORDER BY co.isbn
GO 
	
