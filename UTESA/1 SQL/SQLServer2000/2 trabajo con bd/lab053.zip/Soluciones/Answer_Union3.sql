--*********************************************************************
-- 2317B Pr�ctica 5A:  Consultas a varias tablas
--       EJERCICIO 2:  Uso del operador UNION para combinar conjuntos 
--                     de resultados
--     PROCEDIMIENTO:  Para combinar los conjuntos de resultados de 
--                     consultas independientes
-----------------------------------------------------------------------

USE library
SELECT a.member_no
      ,count(*) AS numkids
 FROM juvenile AS j
 INNER JOIN adult AS a
  ON  j.adult_member_no = a.member_no
 WHERE a.state = 'AZ'
 GROUP BY a.member_no
 HAVING COUNT(*) > 2
UNION
SELECT a.member_no
      ,count(*) AS numkids
 FROM juvenile AS j
 INNER JOIN adult AS a
  ON  j.adult_member_no = a.member_no
 WHERE a.state = 'CA'
 GROUP BY a.member_no
 HAVING COUNT(*) > 3
GO
	
