--*********************************************************************
-- 2317B Pr�ctica 3A:  Recuperaci�n de datos y transformaci�n de 
--                     conjuntos de resultados
--       EJERCICIO 1:  Recuperaci�n de datos
--     PROCEDIMIENTO:  Para seleccionar filas con una comparaci�n de 
--                     cadenas de caracteres
-----------------------------------------------------------------------

USE library
SELECT title_no, title 
FROM title 
WHERE title LIKE ('%Adventures%')
GO
