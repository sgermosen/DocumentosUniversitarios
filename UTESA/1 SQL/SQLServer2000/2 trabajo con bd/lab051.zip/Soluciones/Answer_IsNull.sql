--*********************************************************************
-- 2317B Pr�ctica 3A:  Recuperaci�n de datos y transformaci�n de 
--                     conjuntos de resultados
--       EJERCICIO 1:  Recuperaci�n de datos
--     PROCEDIMIENTO:  Para seleccionar filas que contienen valores 
--                     NULL
-----------------------------------------------------------------------

USE library
SELECT member_no, fine_assessed, fine_paid 
FROM loanhist 
WHERE (fine_assessed IS NOT NULL) AND (fine_paid IS NULL)
GO
