--*********************************************************************
-- 2317B Pr�ctica 3A:  Recuperaci�n de datos y transformaci�n de 
--                     conjuntos de resultados
--       EJERCICIO 3:  Uso de las funciones del sistema
--     PROCEDIMIENTO:  Para determinar el identificador de proceso del 
--                     servidor
-----------------------------------------------------------------------

EXEC sp_who
SELECT @@spid
--EXEC sp_who n
GO
