--*********************************************************************
-- 2317B Pr�ctica 3A:  Recuperaci�n de datos y transformaci�n de 
--                     conjuntos de resultados
--       EJERCICIO 2:  Transformaci�n de conjuntos de resultados
--     PROCEDIMIENTO:  Para dar formato al conjunto de resultados de 
--                     una columna mediante funciones de cadena
-----------------------------------------------------------------------

USE library
SELECT LOWER(firstname + middleinitial 
                         + SUBSTRING(lastname, 1, 2)) AS email_name
 FROM member
 WHERE lastname = 'anderson'
GO
