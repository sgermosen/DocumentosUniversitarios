--*********************************************************************
-- 2317B Pr�ctica 3A:  Recuperaci�n de datos y transformaci�n de 
--                     conjuntos de resultados
--       EJERCICIO 1:  Recuperaci�n de datos
--     PROCEDIMIENTO:  Para seleccionar filas con una lista de valores
-----------------------------------------------------------------------

USE library
SELECT author, title_no 
FROM title 
WHERE author IN ('Charles Dickens','Jane Austen')
GO
