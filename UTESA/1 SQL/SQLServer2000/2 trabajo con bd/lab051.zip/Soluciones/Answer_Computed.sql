--*********************************************************************
-- 2317B Pr�ctica 3A:  Recuperaci�n de datos y transformaci�n de 
--                     conjuntos de resultados
--       EJERCICIO 2:  Transformaci�n de conjuntos de resultados
--     PROCEDIMIENTO:  Para calcular datos, obtener valores calculados
--                     y utilizar un alias de columna
-----------------------------------------------------------------------

USE library
SELECT member_no, isbn, fine_assessed,
       (fine_assessed * 2) AS 'double fine'
FROM loanhist 
WHERE (fine_assessed IS NOT NULL) 
GO
