--*********************************************************************
-- 2317B Pr�ctica 3A:  Recuperaci�n de datos y transformaci�n de 
--                     conjuntos de resultados
--       EJERCICIO 3:  Uso de las funciones del sistema
--     PROCEDIMIENTO:  Para recuperar metadatos
-----------------------------------------------------------------------

USE library
SELECT * FROM information_schema.tables
	WHERE table_type = 'base table'
GO

USE northwind
SELECT * FROM information_schema.key_column_usage
	WHERE table_name = 'orders'
GO
