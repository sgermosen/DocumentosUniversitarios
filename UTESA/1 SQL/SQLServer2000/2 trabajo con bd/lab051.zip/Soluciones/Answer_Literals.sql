--*********************************************************************
-- 2317B Pr�ctica 3A:  Recuperaci�n de datos y transformaci�n de 
--                     conjuntos de resultados
--       EJERCICIO 2:  Transformaci�n de conjuntos de resultados
--     PROCEDIMIENTO:  Para dar formato al conjunto de resultados de 
--                     una columna mediante literales
-----------------------------------------------------------------------

USE library
SELECT 'The title is: ' + title + ', title number ' + 
        CONVERT(char(6),title_no) 
FROM title 
GO
