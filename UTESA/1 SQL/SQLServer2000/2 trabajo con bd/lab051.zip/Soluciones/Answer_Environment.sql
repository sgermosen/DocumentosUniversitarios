--*********************************************************************
-- 2317B Pr�ctica 3A:  Recuperaci�n de datos y transformaci�n de 
--                     conjuntos de resultados
--       EJERCICIO 3:  Uso de las funciones del sistema
--     PROCEDIMIENTO:  Para recuperar informaci�n del entorno
-----------------------------------------------------------------------

SELECT @@version

SELECT USER_NAME(), DB_NAME(), @@servername
GO
