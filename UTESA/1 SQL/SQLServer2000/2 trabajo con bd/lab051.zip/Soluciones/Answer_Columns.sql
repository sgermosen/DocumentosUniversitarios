--*********************************************************************
-- 2317B Pr�ctica 3A:  Recuperaci�n de datos y transformaci�n de 
--                     conjuntos de resultados
--       EJERCICIO 1:  Recuperaci�n de datos
--     PROCEDIMIENTO:  Para seleccionar columnas espec�ficas
-----------------------------------------------------------------------

USE library
SELECT title, title_no 
FROM title
