--*********************************************************************
-- 2317B Pr�ctica 3A:  Recuperaci�n de datos y transformaci�n de 
--                     conjuntos de resultados
--       EJERCICIO 2:  Transformaci�n de conjuntos de resultados
--     PROCEDIMIENTO:  Para eliminar las filas duplicadas del conjunto 
--                     de resultados
-----------------------------------------------------------------------

USE library
SELECT DISTINCT city, state 
FROM adult
GO
