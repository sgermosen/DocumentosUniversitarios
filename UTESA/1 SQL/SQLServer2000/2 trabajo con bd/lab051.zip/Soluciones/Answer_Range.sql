--*********************************************************************
-- 2317B Pr�ctica 3A:  Recuperaci�n de datos y transformaci�n de 
--                     conjuntos de resultados
--       EJERCICIO 1:  Recuperaci�n de datos
--     PROCEDIMIENTO:  Para seleccionar filas con un intervalo
-----------------------------------------------------------------------

USE library
SELECT member_no, fine_assessed 
FROM loanhist 
WHERE (fine_assessed BETWEEN $8.00 AND $9.00)
GO
