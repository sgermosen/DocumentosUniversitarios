--*********************************************************************
-- 2317B Pr�ctica 3A:  Recuperaci�n de datos y transformaci�n de 
--                     conjuntos de resultados
--       EJERCICIO 1:  Recuperaci�n de datos
--     PROCEDIMIENTO:  Para seleccionar filas con un operador de 
--                     comparaci�n
-----------------------------------------------------------------------

USE library
SELECT title 
FROM title 
WHERE title_no = 10
GO
