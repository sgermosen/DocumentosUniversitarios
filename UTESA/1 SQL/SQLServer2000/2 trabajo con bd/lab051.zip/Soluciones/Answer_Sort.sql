--*********************************************************************
-- 2317B Pr�ctica 3A:  Recuperaci�n de datos y transformaci�n de 
--                     conjuntos de resultados
--       EJERCICIO 2:  Transformaci�n de conjuntos de resultados
--     PROCEDIMIENTO:  Para ordenar los datos
-----------------------------------------------------------------------

USE library
SELECT title 
FROM title 
ORDER BY title
GO
