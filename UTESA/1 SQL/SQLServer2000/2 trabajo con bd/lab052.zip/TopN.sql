--*********************************************************************
-- 2317B Pr�ctica 4A:  Resumir datos
--       EJERCICIO 4:  Uso de la palabra clave TOP n
-----------------------------------------------------------------------

USE northwind
SELECT orderid
      ,(unitprice * quantity) AS totalsale
 FROM [order details]
 ORDER BY (unitprice * quantity) DESC
GO
