--*********************************************************************
-- 2317B Pr�ctica 4A:  Resumir datos
--       EJERCICIO 2:  Uso de las cl�usulas GROUP BY y HAVING
--     PROCEDIMIENTO:  Para calcular la cantidad total para cada pedido
-----------------------------------------------------------------------

USE northwind
SELECT orderid, SUM(quantity) AS total_quantity
 FROM [order details] AS od
 INNER JOIN products AS p
  ON od.productid = p.productid
 GROUP BY orderid
GO
