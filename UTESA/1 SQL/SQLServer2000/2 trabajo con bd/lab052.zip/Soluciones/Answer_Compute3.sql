--*********************************************************************
-- 2317B Pr�ctica 4A:  Resumir datos
--       EJERCICIO 4:  Uso de las cl�usulas COMPUTE y COMPUTE BY
--     PROCEDIMIENTO:  Para agregar la cantidad total y cantidad 
--                     promedio al final del informe con secciones
-----------------------------------------------------------------------

USE northwind
SELECT orderid, quantity
 FROM [order details]
 WHERE orderid in ( 11075, 11076 ) 
 ORDER BY orderid
 COMPUTE SUM(quantity) BY orderid
 COMPUTE SUM(quantity)
 COMPUTE AVG(quantity) 
GO
