--*********************************************************************
-- 2317B Pr�ctica 4A:  Resumir datos
--       EJERCICIO 2:  Uso de las cl�usulas GROUP BY y HAVING
--     PROCEDIMIENTO:  Para calcular el n�mero de pedidos con m�s de 
--                     250 unidades pedidas
-----------------------------------------------------------------------

USE northwind
SELECT orderid, SUM(quantity) AS total_quantity
 FROM [order details] AS od
 INNER JOIN products AS p
  ON od.productid = p.productid
 GROUP BY orderid
 HAVING SUM(quantity) > 250
GO
