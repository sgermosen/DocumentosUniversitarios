--*********************************************************************
-- 2317B Pr�ctica 4A:  Resumir datos
--       EJERCICIO 4:  Uso de la palabra clave TOP n
--     PROCEDIMIENTO:  Para utilizar la palabra clave TOP n y presentar 
--                     las primeras filas de un conjunto de resultados
-----------------------------------------------------------------------

USE northwind
SELECT TOP 10
       orderid
      ,(unitprice * quantity) AS totalsale
 FROM [order details]
 ORDER BY (unitprice * quantity) DESC
GO
