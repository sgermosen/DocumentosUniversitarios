--*********************************************************************
-- 2317B Pr�ctica 4A:  Resumir datos
--       EJERCICIO 3:  Uso de los operadores ROLLUP y CUBE
--     PROCEDIMIENTO:  Para utilizar el operador CUBE con el fin de 
--                     generar resultados de resumen
-----------------------------------------------------------------------

USE northwind
SELECT productid
      ,GROUPING(productid)
      ,orderid
      ,GROUPING(orderid)
      ,SUM(quantity) AS total_quantity
 FROM [order details]
 WHERE productid = 50
 GROUP BY productid, orderid
  WITH CUBE
 ORDER BY productid, orderid
GO
