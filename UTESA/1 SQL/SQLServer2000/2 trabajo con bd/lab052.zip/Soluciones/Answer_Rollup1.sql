--*********************************************************************
-- 2317B Pr�ctica 4A:  Resumir datos
--       EJERCICIO 3:  Uso de los operadores ROLLUP y CUBE
--     PROCEDIMIENTO:  Para utilizar el operador ROLLUP con el fin de 
--                     generar resultados de resumen
-----------------------------------------------------------------------

USE northwind
SELECT productid, orderid, SUM(quantity) AS total_quantity
 FROM [order details]
 WHERE productid = 50
 GROUP BY productid, orderid
  WITH ROLLUP
 ORDER BY productid, orderid
GO
