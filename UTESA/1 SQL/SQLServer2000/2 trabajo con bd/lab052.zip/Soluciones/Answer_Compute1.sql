--*********************************************************************
-- 2317B Pr�ctica 4A:  Resumir datos
--       EJERCICIO 4:  Uso de las cl�usulas COMPUTE y COMPUTE BY
--     PROCEDIMIENTO:  Para utilizar la cl�usula COMPUTE con el fin de 
--                     generar informes
-----------------------------------------------------------------------

USE northwind
SELECT orderid, quantity
 FROM [order details]
 WHERE orderid >= 11070
 COMPUTE SUM(quantity) 
GO
