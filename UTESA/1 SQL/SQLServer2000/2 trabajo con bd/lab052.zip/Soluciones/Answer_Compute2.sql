--*********************************************************************
-- 2317B Pr�ctica 4A:  Resumir datos
--       EJERCICIO 4:  Uso de las cl�usulas COMPUTE y COMPUTE BY
--     PROCEDIMIENTO:  Para utilizar la cl�usula COMPUTE BY con el fin 
--                     de generar informes
-----------------------------------------------------------------------

USE northwind
 SELECT orderid, quantity
 FROM [order details]
 WHERE orderid in ( 11075, 11076 ) 
 ORDER BY orderid
 COMPUTE SUM(quantity) BY orderid
GO
