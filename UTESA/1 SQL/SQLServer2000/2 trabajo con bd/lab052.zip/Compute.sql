--*********************************************************************
-- 2317B Pr�ctica 4A:  Resumir datos
--       EJERCICIO 4:  Uso de las cl�usulas COMPUTE y COMPUTE BY
-----------------------------------------------------------------------

USE northwind

SELECT orderid, quantity
  FROM [order details]
  WHERE orderid >= 11070
GO
