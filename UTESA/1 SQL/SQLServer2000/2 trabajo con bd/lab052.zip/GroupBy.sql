--*********************************************************************
-- 2317B Pr�ctica 4A:  Resumir datos
--       EJERCICIO 2:  Uso de las cl�usulas GROUP BY y HAVING
-----------------------------------------------------------------------

USE northwind

SELECT categoryid, SUM(quantity) AS total_quantity
 FROM [order details] AS od
 INNER JOIN products
  ON od.productid = products.productid
 WHERE categoryid <3
 GROUP BY categoryid 
GO
