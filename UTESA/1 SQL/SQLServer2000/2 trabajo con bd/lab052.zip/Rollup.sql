--*********************************************************************
-- 2317B Pr�ctica 4A:  Resumir datos
--       EJERCICIO 3:  Uso de los operadores ROLLUP y CUBE
-----------------------------------------------------------------------

USE northwind

SELECT productid, orderid, SUM(quantity) AS total_quantity
 FROM [order details]
 GROUP BY productid, orderid
  WITH ROLLUP
 ORDER BY productid, orderid
GO
