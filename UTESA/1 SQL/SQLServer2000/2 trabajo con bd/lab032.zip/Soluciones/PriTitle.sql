/*
Adds a PRIMARY KEY CONTSTRAINT to the Cumtomers table. 
*/

USE ClassNorthwind

ALTER TABLE Customers
  ADD CONSTRAINT PK_Customers PRIMARY KEY NONCLUSTERED (CustomerID)

GO

