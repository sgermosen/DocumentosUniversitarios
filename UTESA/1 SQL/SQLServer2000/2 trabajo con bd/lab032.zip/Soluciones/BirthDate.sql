/*
Adds a CHECK CONTSTRAINT to verify that the employee
birth date is less than today's date.
*/

USE ClassNorthwind

ALTER TABLE Employees
 ADD CONSTRAINT CK_BirthDate
  CHECK (BirthDate < GETDATE())
GO

