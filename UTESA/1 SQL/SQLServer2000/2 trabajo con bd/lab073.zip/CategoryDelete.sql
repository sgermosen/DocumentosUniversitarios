/*
**       CategoryDelete.sql
**
**  This file creates two new tables that do not use 
**  constraints to maintain integrity. Then it creates 
**  a delete trigger on the NewCategories
**  table. This trigger updates the Discontinued column 
**  in the NewProducts table whenever a Category is deleted 
**  (whenever a record is deleted from the NewCategories table). 
**  All affected products are marked as 1 indicating they are 
**  discontinued
*/
USE ClassNorthwind
GO

--Create a NewCategories table
SELECT * INTO NewCategories FROM Categories
--Create a NewProducts table
SELECT * INTO NewProducts FROM Products
GO

CREATE TRIGGER Category_Delete
   ON NewCategories
   FOR DELETE
AS
   UPDATE P SET Discontinued = 1
   FROM NewProducts AS P INNER JOIN Deleted AS d
   ON P.CategoryID = D.CategoryID

--Confirm the value of a product
SELECT ProductID, CategoryID, Discontinued 
FROM NewProducts WHERE CategoryID = 7

/*
**  Test the trigger by deleting a category from the 
**  Categories table
*/

DELETE NewCategories WHERE CategoryID = 7

-- Recheck the products
SELECT ProductID, CategoryID, Discontinued 
FROM NewProducts WHERE CategoryID = 7
