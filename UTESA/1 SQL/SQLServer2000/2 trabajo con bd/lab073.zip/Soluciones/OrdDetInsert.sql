/*
**       OrdDetInsert.sql - Answer file
**
**  This file contains a script for the actions in 
**  Exercise 1
*/
/*
**  This file creates an insert trigger on the Order Details
**  table. When a row is inserted into Order Details the 
**  Products table UnitsInStock column is updated to 
**  reduce the amount of stock on hand.
*/

USE ClassNorthwind
/*    
** If the object already exists (i.e., if this is a rebuild), drop it.
*/

IF EXISTS ( SELECT name FROM sysobjects
            WHERE type = 'TR' AND name = 'OrdDet_Insert' )
    DROP TRIGGER OrdDet_Insert
GO

CREATE TRIGGER OrdDet_Insert
ON [Order Details]
FOR INSERT
AS
UPDATE P SET 
UnitsInStock = (P.UnitsInStock - I.Quantity)
FROM Products AS P INNER JOIN Inserted AS I
ON P.ProductID = I.ProductID
GO

/*
** Display results.
*/

SELECT name FROM sysobjects
   WHERE type = 'TR'
   ORDER BY type, name
GO

/*
**Execute sp_helptrigger on the Order Details table
*/
sp_helptrigger [Order Details]

--Check the value of the Products table before the trigger fires
SELECT * FROM Products WHERE ProductID = 22

/* 
**Insert an Order Details record for product 16
*/
INSERT [Order Details] 
(OrderID, ProductID, UnitPrice, Quantity, Discount)
VALUES (11077, 22, 21.00, 50, 0.0)
GO

--Check the value of the Products table to see if it changed
SELECT * FROM Products WHERE ProductID = 22

