/*
**       BusinessRule.sql
**
**  This example creates a trigger that determines 
**  whether any order history exists for a product 
**  that is being deleted. If the product has never 
**  been ordered then the product can be deleted. 
**  If the product has a history of orders then the 
**  delete from the product table is rolled back 
**  and the trigger returns a custom error message. 
*/

USE ClassNorthwind
GO

CREATE TRIGGER Product_Delete
  ON NewProducts FOR DELETE
AS
IF (Select Count (*)
    FROM [Order Details] INNER JOIN deleted 
    ON [Order Details].ProductID = Deleted.ProductID
    ) > 0 
BEGIN
   RAISERROR('Transaction cannot be processed. This Product still has a history of orders.', 16, 1)
   ROLLBACK TRANSACTION
END

--Test the trigger 
DELETE NewProducts WHERE ProductID = 6
