/*
**       CREATINDX3.SQL
**  
**  Crea todos los �ndices de claves externas.
**
**  Primero borra los �ndices antiguos.
**
**  Todas las tablas que se actualizan durante el funcionamiento diario normal ser�n
**      dadas de un FILLFACTOR.  De forma moderada, las tablas vol�tiles tendr�n bastante
**      espacio libre para una fila nueva.  Las tablas vol�tiles, como Loan, tendr�n
**      m�s espacio libre.  De forma relativa, las tablas est�ticas no tendr�n
**      espacio.
**  
**  No olvide especificar primero 'USE library'.
*/

USE library
SET NOCOUNT ON
GO

/*    
**  Si ya existen los objetos (por ejemplo, si esto es una reconstrucci�n), b�rrelos.
*/

IF EXISTS (SELECT name FROM sysindexes WHERE name = 'juvenile_member_link')
    DROP INDEX  juvenile.juvenile_member_link
IF EXISTS (SELECT name FROM sysindexes WHERE name = 'item_title_link')
    DROP INDEX  item.item_title_link
IF EXISTS (SELECT name FROM sysindexes WHERE name = 'copy_title_link')
    DROP INDEX  copy.copy_title_link
IF EXISTS (SELECT name FROM sysindexes WHERE name = 'loan_title_link')
    DROP INDEX  loan.loan_title_link
IF EXISTS (SELECT name FROM sysindexes WHERE name = 'loan_member_link')
    DROP INDEX  loan.loan_member_link
IF EXISTS (SELECT name FROM sysindexes WHERE name = 'reserve_item_link')
    DROP INDEX  reservation.reserve_item_link
IF EXISTS (SELECT name FROM sysindexes WHERE name = 'loanhist_member_link')
    DROP INDEX  loanhist.loanhist_member_link
IF EXISTS (SELECT name FROM sysindexes WHERE name = 'loanhist_title_link')
    DROP INDEX  loanhist.loanhist_title_link
GO

DUMP TRANSACTION library WITH TRUNCATE_ONLY
GO

/***************************  Crea los �ndices. ***************************/

/******  �ndices relacionados de Member.  ******/

DECLARE @message char(255)  DECLARE @began datetime
SELECT @began = GETDATE()

CREATE	NONCLUSTERED INDEX juvenile_member_link ON juvenile (adult_member_no)

SELECT @message = 'Time (in minutes:seconds) to create Member related indexes.  '
     + CONVERT( char(2), DATEDIFF(ss,@began,GETDATE())/60 ) + ':'
     + CONVERT( char(2), DATEDIFF(ss,@began,GETDATE())%60 )
PRINT @message
GO

/******  �ndices relacionados de Book.  ******/

DECLARE @message char(255)  DECLARE @began datetime  SELECT @began = GETDATE()

CREATE	   CLUSTERED INDEX item_title_link   ON item        (title_no)
CREATE     CLUSTERED INDEX copy_title_link   ON copy        (title_no)
CREATE     CLUSTERED INDEX loan_title_link   ON loan        (title_no)
CREATE  NONCLUSTERED INDEX loan_member_link  ON loan        (member_no)
    WITH FILLFACTOR = 75
CREATE     CLUSTERED INDEX reserve_item_link ON reservation (isbn)

SELECT @message = 'Time (in minutes:seconds) to create Book related indexes.  '
     + CONVERT( char(2), DATEDIFF(ss,@began,GETDATE())/60 ) + ':'
     + CONVERT( char(2), DATEDIFF(ss,@began,GETDATE())%60 )
PRINT @message
GO

DUMP TRANSACTION library WITH TRUNCATE_ONLY
GO


/******  �ndices relacionados de Loan History.  ******/

DECLARE @message char(255)  DECLARE @began datetime  SELECT @began = GETDATE()

CREATE	NONCLUSTERED INDEX loanhist_member_link ON loanhist (member_no)
CREATE	NONCLUSTERED INDEX loanhist_title_link  ON loanhist (title_no)

SELECT @message = 'Time (in minutes:seconds) to create Loan History related indexes.  '
     + CONVERT( char(2), DATEDIFF(ss,@began,GETDATE())/60 ) + ':'
     + CONVERT( char(2), DATEDIFF(ss,@began,GETDATE())%60 )
PRINT @message
GO


/***************  Muestra el resultado  ***************/

PRINT 'CREATED INDEXES:'
SELECT name FROM sysindexes
   WHERE name IN (  'juvenile_member_link'
                   , 'item_title_link'
                   , 'copy_title_link'
                   , 'loan_title_link'
                   , 'loan_member_link'
                   , 'reserve_item_link'
                   , 'loanhist_member_link'
                   , 'loanhist_title_link'
                 )


PRINT 'SPACE REQUIRED:'
EXEC  sp_spaceused
EXEC  sp_spaceused juvenile
EXEC  sp_spaceused item
EXEC  sp_spaceused copy
EXEC  sp_spaceused loan
EXEC  sp_spaceused reservation
EXEC  sp_spaceused loanhist
GO


/*  Trunca el registro.  */

DUMP TRANSACTION library WITH TRUNCATE_ONLY
GO

SET NOCOUNT OFF
GO
