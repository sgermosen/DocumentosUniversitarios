--*********************************************************************
-- 2317B Pr�ctica 6A:  Trabajo con subconsultas
--       EJERCICIO 2:  Uso de una subconsulta como una expresi�n
--     PROCEDIMIENTO:  Para utilizar una consulta con el fin de crear 
--                     una lista de valores
-----------------------------------------------------------------------

USE library
SELECT isbn
 FROM reservation
 GROUP BY isbn
 HAVING COUNT(*)> 50
GO

USE Library
SELECT t.title_no, title, l.isbn
      ,count(*) AS 'Total Reserved'
 FROM title AS t
 INNER JOIN loan AS l
  ON t.title_no = l.title_no
 INNER JOIN reservation AS r
  ON r.isbn = l.isbn
 WHERE r.isbn IN 
      ( SELECT isbn
         FROM reservation
         GROUP BY isbn
         HAVING COUNT(*)> 50 )
  AND  l.copy_no < 5
 GROUP BY t.title_no, title, l.isbn
GO
	
