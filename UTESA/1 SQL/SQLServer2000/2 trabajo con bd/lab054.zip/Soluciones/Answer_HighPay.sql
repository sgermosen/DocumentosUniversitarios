--*********************************************************************
-- 2317B Pr�ctica 6A:  Trabajo con subconsultas
--       EJERCICIO 2:  Uso de una subconsulta como una expresi�n
--     PROCEDIMIENTO:  Para utilizar una subconsulta de un �nico valor
-----------------------------------------------------------------------

USE Library
SELECT MAX(fine_paid)
 FROM loanhist
GO

USE library
SELECT DISTINCT firstname, lastname, isbn, fine_paid
 FROM member AS m
 INNER JOIN loanhist AS lh
  ON m.member_no = lh.member_no
 WHERE lh.fine_paid = (SELECT MAX(fine_paid) FROM loanhist)
GO
	
