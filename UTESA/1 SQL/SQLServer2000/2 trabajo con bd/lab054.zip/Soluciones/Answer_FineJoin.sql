--*********************************************************************
-- 2317B Pr�ctica 6A:  Trabajo con subconsultas
--       EJERCICIO 3:  Uso de una subconsulta para correlacionar datos
--     PROCEDIMIENTO:  Para utilizar una subconsulta correlacionada - 
--                     NOTA
-----------------------------------------------------------------------

USE LIBRARY
SELECT m.member_no, lastname, SUM(fine_assessed) AS 'Total Fines'
 FROM member AS m
 INNER JOIN loanhist AS lh
  ON m.member_no = lh.member_no
 GROUP BY m.member_no, lastname
 HAVING SUM(fine_assessed) > 5
GO
	
