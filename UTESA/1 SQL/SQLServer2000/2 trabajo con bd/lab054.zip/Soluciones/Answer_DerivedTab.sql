--*********************************************************************
-- 2317B Pr�ctica 6A:  Trabajo con subconsultas
--       EJERCICIO 1:  Uso de una subconsulta como una tabla derivada
--     PROCEDIMIENTO:  Para ejecutar una consulta que utiliza una 
--                     tabla derivada
-----------------------------------------------------------------------

USE library
SELECT d.adult_member_no, a.expr_date, d.No_Of_Children
 FROM adult AS a
 INNER JOIN (
         SELECT adult_member_no, COUNT(*) AS No_Of_Children
          FROM juvenile
          GROUP BY adult_member_no
          HAVING COUNT(*) > 3
         ) AS d
   ON a.member_no = d.adult_member_no
GO
	
