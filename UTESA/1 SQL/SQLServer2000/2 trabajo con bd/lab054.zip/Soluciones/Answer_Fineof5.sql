--*********************************************************************
-- 2317B Pr�ctica 6A:  Trabajo con subconsultas
--       EJERCICIO 3:  Uso de una subconsulta para correlacionar datos
--     PROCEDIMIENTO:  Para utilizar una subconsulta correlacionada
-----------------------------------------------------------------------

USE Library
SELECT member_no, lastname
 FROM member AS m
GO

USE library
SELECT member_no, lastname
 FROM member AS m
 WHERE 5 < ( SELECT SUM(fine_assessed)
              FROM loanhist AS lh
              WHERE m.member_no = lh.member_no )
GO
	
