USE ClassNorthwind
GO
ALTER PROCEDURE SupplierProductInsert
        @CompanyName nvarchar (40) = NULL,
        @ContactName nvarchar (40) = NULL,
        @ContactTitle nvarchar (40)= NULL,
        @Address nvarchar (60) = NULL,
        @City nvarchar (15) = NULL,
        @Region nvarchar (40) = NULL,
        @PostalCode nvarchar (10) = NULL,
        @Country nvarchar (15) = NULL,
        @Phone nvarchar (24) = NULL,
        @Fax nvarchar (24) = NULL,
        @HomePage ntext = NULL,
        @ProductName nvarchar (40) = NULL,
        @CategoryID int = NULL,
        @QuantityPerUnit nvarchar (20) = NULL, 
        @UnitPrice money = NULL, 
        @UnitsInStock smallint = NULL,
        @UnitsOnOrder smallint = NULL,
        @ReorderLevel smallint = NULL,
        @Discontinued bit  = NULL
AS 
    IF  @CompanyName     IS NULL OR
	@ContactName     IS NULL OR
	@Address         IS NULL OR
        @City            IS NULL OR
        @Region          IS NULL OR
        @PostalCode      IS NULL OR
	@Country         IS NULL OR
	@Phone           IS NULL OR
	@ProductName     IS NULL OR
	@CategoryID      IS NULL OR
	@QuantityPerUnit IS NULL OR
	@Discontinued    IS NULL
    BEGIN
      PRINT 'You must provide Company Name, Contact Name, Address, City'
      PRINT 'Region, Postal Code, Country, Phone, Product Name, and Discontinued'
      PRINT '(Contact Title, Fax, Home Page, Unit Price, Units in Stock
	      Units on Order and Reorder Level can be null.)'
      RETURN
    END

DECLARE @UserName nvarchar (60)
SELECT @UserName = suser_sname()

BEGIN TRANSACTION
	INSERT Suppliers (
		CompanyName, 
		ContactName,  
		Address, 
		City, 
		Region, 
		PostalCode, 
		Country, 
		Phone)
	VALUES (
		@CompanyName, 
		@ContactName, 
		@Address, 
		@City, 
		@Region,
		@PostalCode, 
		@Country, 
		@Phone)
		IF @@error <> 0
			BEGIN
				ROLLBACK TRAN
				RETURN
			END
	DECLARE @InsertSupplierID int
	SELECT @InsertSupplierID=@@identity
	INSERT Products (
		ProductName, 
		SupplierID, 
		CategoryID, 
		QuantityPerUnit, 
		Discontinued)
	VALUES (
		@ProductName, 
		@InsertSupplierID, 
		@CategoryID, 
		@QuantityPerUnit, 
		@Discontinued)
		IF @@error <> 0
			BEGIN
				ROLLBACK TRAN
				RETURN
			END

RAISERROR (50018, 16, 1, @InsertSupplierID, @UserName)
         PRINT '*** New Product and Supplier added ***   '

COMMIT TRANSACTION
GO

EXEC sp_addmessage 50018, 16, 'Supplier %d was inserted by %s', 'us_english', 'true', 'replace'

GO