/*
This script executes the OrderCount stored procedure with respect
to customer WOLZA and demonstrates the use of the OUTPUT keyword. 
*/

USE ClassNorthwind
GO
DECLARE 
 @CustomerID  nchar (5),
 @Message        varchar(80),
 @ReturnCode    int,
 @NumberOrders  int

SET @CustomerID = 'WOLZA'   -- change this Customer ID as desired

EXEC @ReturnCode = OrderCount @CustomerID, @NumberOrders OUTPUT

IF @ReturnCode = 1
BEGIN
  SELECT @Message =
    'Customer ' + 
    RTRIM(CONVERT(char(8),@CustomerID)) +
    ' has ' +
    RTRIM(CONVERT(char(8),@NumberOrders)) +
    ' unfilled order(s).'
  RAISERROR (@Message, 10 ,1)
END
ELSE
BEGIN
  SELECT @Message =
    'Customer ' +
    RTRIM(convert(char(8),@CustomerID)) +
    ' has NO unfilled order(s).'
  RAISERROR (@Message, 10 ,1)
END
GO
