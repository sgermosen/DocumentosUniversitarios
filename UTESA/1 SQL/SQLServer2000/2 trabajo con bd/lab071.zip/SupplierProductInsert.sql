/* 
Use this script to insert a new product and a new supplier using the 
AddSupplierProduct stored procedure.
Modify parameter values to insert a new product and a new supplier. 
*/

USE ClassNorthwind
GO

EXEC SupplierProductInsert
        @CompanyName = 'New Company',
        @ContactName = 'New Contact Name',
        @Address = 'New Address',
        @City = 'New City',
        @Region = 'New Region',
        @PostalCode = 'New Postal Code',
        @Country = 'New Country',
        @Phone = 'New Phone',
        @ProductName = 'New Product',
        @CategoryID = '1',
        @QuantityPerUnit = '1', 
        @UnitPrice = 1, 
        @Discontinued = 0