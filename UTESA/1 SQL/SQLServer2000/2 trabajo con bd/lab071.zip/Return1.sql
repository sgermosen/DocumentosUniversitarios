/*
This script creates the stored procedure, LOANCOUNT,
that returns a status of 1 if a member has any
loans. If a member has no loans, it returns a 
status of 0.
*/

USE ClassNorthwind
GO

CREATE PROC dbo.OrderCount
    @CustomerID nchar (5),
    @OrderCount int OUTPUT
AS
IF EXISTS 
  (SELECT * FROM Orders WHERE CustomerID = @CustomerID AND ShippedDate IS Null)
  BEGIN
     SELECT @OrderCount=COUNT(*) 
     FROM Orders 
     WHERE CustomerID = @CustomerID 
     RETURN (1) 
  END 
ELSE RETURN (0)
GO