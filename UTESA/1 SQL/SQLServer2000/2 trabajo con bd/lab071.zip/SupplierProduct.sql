USE ClassNorthwind
GO
/* If the object already exists in the database, drop it. */
IF OBJECT_ID('SupplierProductInsert') IS NOT NULL
DROP PROCEDURE SupplierProductInsert
GO
CREATE PROCEDURE SupplierProductInsert
        @CompanyName nvarchar (40) = NULL,
        @ContactName nvarchar (40) = NULL,
        @ContactTitle nvarchar (40)= NULL,
        @Address nvarchar (60) = NULL,
        @City nvarchar (15) = NULL,
        @Region nvarchar (40) = NULL,
        @PostalCode nvarchar (10) = NULL,
        @Country nvarchar (15) = NULL,
        @Phone nvarchar (24) = NULL,
        @Fax nvarchar (24) = NULL,
        @HomePage ntext = NULL,
        @ProductName nvarchar (40) = NULL,
        @CategoryID int = NULL,
        @QuantityPerUnit nvarchar (20) = NULL, 
        @UnitPrice money = NULL, 
        @UnitsInStock smallint = NULL,
        @UnitsOnOrder smallint = NULL,
        @ReorderLevel smallint = NULL,
        @Discontinued bit  = NULL
AS 
    IF  @CompanyName     IS NULL OR
	@ContactName     IS NULL OR
	@Address         IS NULL OR
        @City            IS NULL OR
        @Region          IS NULL OR
        @PostalCode      IS NULL OR
	@Country         IS NULL OR
	@Phone           IS NULL OR
	@ProductName     IS NULL OR
	@CategoryID      IS NULL OR
	@QuantityPerUnit IS NULL OR
	@Discontinued    IS NULL
    BEGIN
      PRINT 'You must provide Company Name, Contact Name, Address, City'
      PRINT 'Region, Postal Code, Country, Phone, Product Name, and Discontinued.'
      PRINT '(Contact Title, Fax, Home Page, Unit Price, Units in Stock
	      Units on Order and Reorder Level can be null.)'
      RETURN
    END



BEGIN TRANSACTION
	INSERT Suppliers (
		CompanyName, 
		ContactName,  
		Address, 
		City, 
		Region, 
		PostalCode, 
		Country, 
		Phone)
	VALUES (
		@CompanyName, 
		@ContactName, 
		@Address, 
		@City, 
		@Region,
		@PostalCode, 
		@Country, 
		@Phone)
		IF @@error <> 0
			BEGIN
				ROLLBACK TRAN
				RETURN
			END
	DECLARE @InsertSupplierID int
	SELECT @InsertSupplierID=@@identity
	INSERT Products (
		ProductName, 
		SupplierID, 
		CategoryID, 
		QuantityPerUnit, 
		Discontinued)
	VALUES (
		@ProductName, 
		@InsertSupplierID, 
		@CategoryID, 
		@QuantityPerUnit, 
		@Discontinued)
		IF @@error <> 0
			BEGIN
				ROLLBACK TRAN
				RETURN
			END
         PRINT '*** New Product and Supplier added ***   '

COMMIT TRANSACTION
GO