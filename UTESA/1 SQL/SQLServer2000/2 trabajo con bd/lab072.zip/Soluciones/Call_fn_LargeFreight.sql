/*
**       Call_fn_LargeFreight.sql
**
**  This statement calls the fn_LargeFreight function
**  with $600 as its parameter to return information 
**  from the Orders and Shippers tables for orders with.
**  more than $600 of freight charges
*/

SELECT * FROM fn_LargeFreight(600)
