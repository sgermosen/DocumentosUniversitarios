/*
**       fn_LargeFreight.sql
**
**  This in-line table-valued user-defined
**  function takes a dollar amount as its parameter
**  and returns information from the Orders and 
**  the Shippers table.
*/

USE ClassNorthwind
GO

CREATE FUNCTION fn_LargeFreight 
   (@FreightAmt money)
RETURNS TABLE
AS 
RETURN
(  SELECT S.ShipperID, S.CompanyName,
      O.OrderID, O.ShippedDate, O.Freight
   FROM Shippers AS S JOIN Orders AS O
      ON S.ShipperID = O.ShipVia
   WHERE O.Freight > @FreightAmt
)
