/*
**       Call_fn_FindReports.sql
**
**  This script shows how to call the user-defined 
**  function defined in fn_FindReports.sql
*/

SELECT EmployeeID, [Name], Title, MgrEmployeeID FROM dbo.fn_FindReports(5)

SELECT EmployeeID, [Name], Title, MgrEmployeeID FROM dbo.fn_FindReports(2)
