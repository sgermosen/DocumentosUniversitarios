/*
**       fn_TaxRate.sql
**
**  This scalar user-defined function uses a case 
**  statement to provide a multiplier for three 
**  different tax rates (0%, 5%, and 10%) that 
**  vary depending on the CategoryID if the product.
**  For instance the condiments category (2) has 
**  no tax, the dairy products category (4)has a  
**  5% tax, and the beverage category (1) has a
**  10% tax. 
*/
USE ClassNorthwind
GO

CREATE FUNCTION fn_TaxRate 
   (@ProdID INT)
RETURNS numeric(5,4)
AS
BEGIN
RETURN
(SELECT 
   CASE CategoryID 
      WHEN 1 THEN 1.10
      WHEN 2 THEN 1
      WHEN 3 THEN 1.10
      WHEN 4 THEN 1.05
      WHEN 5 THEN 1
      WHEN 6 THEN 1.05
      WHEN 7 THEN 1
      WHEN 8 THEN 1.05
   END
FROM Products  
WHERE ProductID = @ProdID)
END
GO

/*
**  This statement uses the fn_TaxRate function
**  to return the price of each product before
**  and after the tax rate is applied
*/

SELECT ProductName, UnitPrice, CategoryID, ClassNorthwind.dbo.fn_TaxRate(ProductID) AS TaxRate, 
UnitPrice * ClassNorthwind.dbo.fn_TaxRate(ProductID) AS PriceWithTax FROM Products
