/*
**       TaxRate.sql
**
**  This example shows a SQL statement that 
**  provides a multiplier for three different
**  tax rates (0%, 5%, and 10%) that vary
**  depending on the CategoryID if the product.
**  For instance the condiments category (2) has 
**  no tax, the dairy products category (4)has a  
**  5% tax, and the beverage category (1) has a
**  10% tax. 
*/

USE ClassNorthwind
GO


SELECT 
   ProductID, CategoryID,
   CASE CategoryID 
      WHEN 1 THEN 1.10
      WHEN 2 THEN 1
      WHEN 3 THEN 1.10
      WHEN 4 THEN 1.05
      WHEN 5 THEN 1
      WHEN 6 THEN 1.05
      WHEN 7 THEN 1
      WHEN 8 THEN 1.05
   END AS TaxRate
FROM Products  