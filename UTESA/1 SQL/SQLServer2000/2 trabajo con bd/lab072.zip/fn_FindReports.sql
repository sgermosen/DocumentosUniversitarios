/*
**       fn_FindReports.sql
**
**  This multi-statement table-valued user-defined
**  function takes an EmplyeeID number as its parameter
**  and provides information about all employees who
**  report to that person.
*/

USE ClassNorthwind
GO

/*
**  As a multi-statement table-valued user-defined
**  function it starts with the function name,
**  input parameter definition and defines the output
**  table.
*/
CREATE FUNCTION fn_FindReports (@InEmployeeID char(5))
RETURNS @reports TABLE
		(EmployeeID char(5) PRIMARY KEY,
		Name nvarchar(40) NOT NULL,
		Title nvarchar(30),
		MgrEmployeeID int,
		processed tinyint default 0)

-- Returns a result set that lists all the employees who 
-- report to a given employee directly or indirectly

AS
BEGIN
	DECLARE @RowsAdded int

	-- Initialize @reports with direct reports of the given employee
	INSERT @reports
		SELECT EmployeeID, Name = FirstName + ' ' + LastName, Title, ReportsTo, 0
		FROM EMPLOYEES
		WHERE ReportsTo = @InEmployeeID

	SET @RowsAdded = @@rowcount

	-- While new employees were added in the previous iteration
	WHILE @RowsAdded > 0
	BEGIN
		-- Mark all employee records whose direct reports are going to be
		-- found in this iteration
		UPDATE @reports
		SET processed = 1
		WHERE processed = 0
		
		-- Insert employees who report to employees marked 1
		INSERT @reports
			SELECT e.EmployeeID, Name = FirstName + ' ' + LastName , e.Title, e.ReportsTo, 0
			FROM employees e, @reports r
			WHERE  e.ReportsTo = r.EmployeeID
			AND r.processed = 1

		SET @RowsAdded = @@rowcount

		-- Mark all employee records whose direct reports hae been
		-- found in this iteration
		UPDATE @reports
		SET processed = 2
		WHERE processed = 1
	END

RETURN -- Provides the value of @reports as the result
END
GO
