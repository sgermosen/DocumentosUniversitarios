document.onreadystatechange = evt_OnReadyStateChange;


function evt_OnReadyStateChange()
{
	if (document.readyState != 'complete')
		return;

	oLMSAPI = FindLMSAPI();

	if(null != oLMSAPI)
	{
		oLMSAPI.LRNListenForEvents(mf_EventHandler);
	}

	document.all("__idselectctrl").onclick = evt_OnClick;
	document.all("__idtreectrl").onclick = evt_OnClick;

	f_Init();
}

window.onbeforeunload = onunload;

function onunload()
{
	if(null != oLMSAPI)
	{
		oLMSAPI.LRNUnListenForEvents(mf_EventHandler);
	}
}


oLMSAPI = null;

var m_bInitialized = false;
var m_objLastPickElement = null;

var CPO_NEXT = 0;
var CPO_PREVIOUS = 1;
var CPO_SELECT = 2;
var CPO_INIT = 3;
var CPO_LESSONSTATUS = 4;
var CPO_EXITSTATUS = 5;


function mf_EventHandler(obj)
{
	switch(obj.type)
	{
	 case CPO_INIT:
		f_Init();
		break;
	 case CPO_LESSONSTATUS:
		var sID = obj.id;
		var strNewStatus = oLMSAPI.LRNGetScopedValue("cmi.core.lesson_status", sID);
		mf_UpdateStatus(sID, strNewStatus);
		if (strNewStatus == "completed")
			oLMSAPI.LRNDoNext();
		break;
	 case CPO_EXITSTATUS:
		var sID = obj.id;
		var strNewStatus = oLMSAPI.LRNGetScopedValue("cmi.core.exit", sID);
		if (strNewStatus == "suspend")
			oLMSAPI.LRNDoPrevious();
		if (strNewStatus == "logout")
			alert ("The LRN Content Viewer received a CMI logout request - close the browser window to exit");
			window.close();
		break;
	 case 0:
	 case 1:
	 case 2:
		mf_SelectNode(obj.id, false, obj.type);
		break;
	default:
		return;

	}
}


function evt_OnClick()
{
	var node = null;

	switch(event.srcElement.name)
	{
		case "link":
			node = event.srcElement.parentElement.parentElement;
			break;
		case "Item_Img":
			node = event.srcElement.parentElement.parentElement;
			break;
		case "Node":
			node = event.srcElement;
			break;
		default:
			return;
	}

	event.cancelBubble=true;
	event.returnValue=false;
	if(null != oLMSAPI)
	{
		oLMSAPI.LRNDoSelect(node.id);
	}
}


///////////////////////////////////////////////////////////////////////////////////////////////////
//
//	@doc INTERNAL
//	@jsfunc  f_Init|Initialize the syllabus tree.
//
//	@rdesc none
//	@comm
//
///////////////////////////////////////////////////////////////////////////////////////////////////
function f_Init()
{
	if(m_bInitialized == true)
	{
		return true;
	}

	if(null == oLMSAPI)
	{
		return false;
	}

	if(false == oLMSAPI.LRNIsReady())
	{
		return false;
	}

	//write the tocs select element, if necessary.
	mf_RenderMultipleTOCS();

	mf_SelectTOC();

	m_bInitialized = true;

	return true;
}


///////////////////////////////////////////////////////////////////////////////////////////////////
//
//	@doc INTERNAL
//	@jsfunc  mf_GetTOC |Get the tocs.
//
//	@rdesc returns an empty string if no toc is found
//	@comm  null will return all the tocs, instead of just the id specified.
//
///////////////////////////////////////////////////////////////////////////////////////////////////

function mf_RenderMultipleTOCS()
{
	if(null != oLMSAPI)
	{
		var oNodes = oLMSAPI.LRNGetTOCS();

		if (oNodes)
		{
			var oTOCS = oNodes.documentElement.childNodes;

			if (oTOCS.length < 2)
				return;

			var oSelect = this.all("__idselectctrl");
			var oTOC = null;

			while (oTOC = oTOCS.nextNode())
			{
				var oOption = document.createElement("option");
				if (oOption)
				{
					var szTitle = "";
					var szId = "";

					var oTitle = oTOC.attributes.getNamedItem("Title");
					var oID = oTOC.attributes.getNamedItem("ID");
					var szIsDefault = oTOC.attributes.getNamedItem("IsDefault");

					if (oTitle)
						szTitle = oTitle.nodeValue;

					if (oID)
						szId = oID.nodeValue;

					oOption.text = szTitle;
					oOption.value = szId;
					oSelect.add(oOption);
					oOption = null;
				}
			}
			oSelect.style.display = "block";
		}
	}
	return;
}


function mf_SelectTOC()
{
		m_objLastPickElement = null;

		if(null != oLMSAPI)
		{
			oLMSAPI.LRNSetCurrentTOC(document.all('__idselectctrl').value);
		}

		//write the tree nodes.
		document.all("__idtreectrl").innerHTML = "";
		document.all("__idtreectrl").innerHTML = mf_GetChildrenHTML(null);

		if(null != oLMSAPI)
		{
			//var nLocID = oLMSAPI.LMSGetValue("lrn.startlocation")
			//if ( nLocID != "")
			//	oLMSAPI.LRNDoSelect(nLocID);
			//else
				oLMSAPI.LRNDoSelectFirst();
		}

}


///////////////////////////////////////////////////////////////////////////////////////////////////
//
//	@doc INTERNAL
//	@jsfunc  mf_GetChildrenHTML |Get the tocs.
//
//	@rdesc returns the html of the children of the specified node. if id is null, the top level is retrieved.
//	@comm
//
///////////////////////////////////////////////////////////////////////////////////////////////////
function mf_GetChildrenHTML(id)
{
	var sInnerHTML = "";

	if(null != oLMSAPI)
	{
		var oNodes = oLMSAPI.LRNGetChildren(id);

		//set the image path.

		//now do the transform with our xsl.
		var oXSL = new ActiveXObject("Msxml2.DOMDocument.3.0");

		mf_LoadXMLData(oXSL, "UISkin.xsl")
		sInnerHTML = oNodes.transformNode(oXSL);
	}
	return sInnerHTML;
}


//helper function to load xml data.
function mf_LoadXMLData(oXMLDOM, sXML)
{
	if (oXMLDOM )
	{
		oXMLDOM.async = false;
		oXMLDOM.validateOnParse = false;

		if (false ==  oXMLDOM.load(sXML) )
		{
			alert(oXMLDOM.parseError.reason + " " + oXMLDOM.parseError.line);
		}
	}
}


function mf_SelectNode(id,fNoCollapse,ntype)
{
	mf_RemoveSelectUI(m_objLastPickElement);
	m_objLastPickElement = document.all("__idtreectrl").all(id);

	//check to see if not retrieved from the xmldom yet.
	if (!m_objLastPickElement)
	{
		if(null != oLMSAPI)
		{
			var oXML = oLMSAPI.LRNGetItem(id);

			if (oXML.documentElement.childNodes(0))
			{
				var szID = oXML.documentElement.childNodes(0).getAttribute("ParentID")

				if (szID != "")
				{
					mf_SelectNode(szID, true,ntype);
					mf_RemoveSelectUI(m_objLastPickElement);
					m_objLastPickElement = this.all("__idtreectrl").all(id);
				}
				else
				{
					// id may change when working with sub-manifests
					var newid = oXML.documentElement.childNodes(0).getAttribute("ID")
					m_objLastPickElement = this.all("__idtreectrl").all(newid);
				}
			}
		}
	}

	var oParent = document.all("__idtreectrl").all(m_objLastPickElement.ParentID);

	if (oParent && oParent.children("__idChildrenContainer").style.display == "none")
	{
		mf_SelectNode(oParent.ID, true,ntype);
		mf_RemoveSelectUI(m_objLastPickElement);
		m_objLastPickElement = this.all("__idtreectrl").all(id);
	}

	//get the children if necessary.
	if (m_objLastPickElement.HasChildren == "1")
	{
		if (m_objLastPickElement.children("__idChildrenContainer").children.length == 0 )///need to get the children
		{
			sInnerHTML = mf_GetChildrenHTML(id);
			m_objLastPickElement.children("__idChildrenContainer").innerHTML = sInnerHTML;
		}
	}



	mf_AddSelectUI(m_objLastPickElement,fNoCollapse, ntype);

	//set personalization
	if(null != oLMSAPI)
	{
		oLMSAPI.LMSSetValue("lrn.startlocation", id);
	}

}


function mf_RemoveSelectUI(node)
{
	if (!node)
		return;

	node.children("__idParent").children("__idLinkCaption").className="A";
	node.children("__idParent").children("__idLinkCaption").style.fontWeight="normal";
}


function mf_AddSelectUI(node, fNoCollapse, ntype)
{
	if (!node)
		return;

	node.children("__idParent").children("__idLinkCaption").style.fontWeight="bold";
	node.children("__idParent").children("__idLinkCaption").className="NavShadedLink";


	if(node.children("__idChildrenContainer").style.display == "none")
		mf_ExpandNode(node,ntype);
	else
		if (false == fNoCollapse && ntype == CPO_SELECT)
			mf_CollapseNode(node,ntype);

	if (ntype != CPO_SELECT) //we are not using scrollinto view because of flicker.
		window.scrollTo( 0 ,node.offsetTop - ( parent.document.body.clientHeight / 2 ) );

	//navigate.

	if (node.Href != "")
	{
		if (node.Href.indexOf("http:") != -1 || node.Href.indexOf("https:") != -1 || node.Href.indexOf("file:") != -1 || node.Href.indexOf("\\\\") != -1 )
		{
			parent.frames.__idParentUIFrameset.children(1).src = node.Href;
		}
		else if (node.Href.indexOf("lrn:") != -1)
		{
			parent.parent.document.location = "../../../" + node.Href.substring(4);
		}
		else if (node.Href.indexOf("home:") != -1)
		{
			s = parent.parent.parent.document.frames[0].name;

			parent.parent.document.location = "../../../../" + s + "/index.html";
		}
		else
		{
			parent.frames.__idParentUIFrameset.children(1).src = "../../../" + node.Href;
		}
	}
}


///////////////////////////////////////////////////////////////////////////////////////////////////
//
//	@doc INTERNAL
//	@jsfunc  mf_ExpandNode |Expand this node.
//
//	@rdesc none
//	@comm
//
///////////////////////////////////////////////////////////////////////////////////////////////////

function mf_ExpandNode(node,ntype)
{
	if (!node)
		return;

	if(node.children("__idChildrenContainer").children.length > 0) //is this a parent or a child.
	{
		if (node.children("__idChildrenContainer").style.display == "none")
				node.children("__idChildrenContainer").style.display = "block";

		node.children("__idParent").children("__idItem_Img").src =node.children("__idParent").children("__idItem_Img").img_expand;
	}
	else
		node.children("__idChildrenContainer").style.display = "none";
}


///////////////////////////////////////////////////////////////////////////////////////////////////
//
//	@doc INTERNAL
//	@jsfunc  mf_CollapseNode |Expand this node.
//
//	@rdesc none
//	@comm
//
///////////////////////////////////////////////////////////////////////////////////////////////////

function mf_CollapseNode(node,ntype)
{

	if (!node)
		return;

	var imgObj = node.children("__idParent").children("__idItem_Img");
	var childrenObj = node.children("__idChildrenContainer");

	childrenObj.style.display = "none";
	imgObj.src = imgObj.img_collapse;
}


function mf_UpdateStatus(id, strNewStatus)
{
	var oNode = this.all("__idtreectrl").all(id);
	var strImg = "";

	if (!oNode)
		return;

	oNode.children("__idParent").children("__idItemStatusImg").src = strNewStatus + ".gif";
}
